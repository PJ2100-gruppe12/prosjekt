CREATE TABLE IF NOT EXISTS `pj_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `pj_users`;
 
INSERT INTO `pj_users` VALUES ('1', 'nessol13', '$P$B9df8rhZp9JgeVvvXIpfmOUSz.v.961', 'nessol13', 'nessol13@nith.no', '', '2014-03-10 14:47:05', '', '0', 'nessol13'); 
INSERT INTO `pj_users` VALUES ('2', 'ervleo13', '$P$BPZLZDK.FSiWezAKX.QkwN6IR5rJOm/', 'ervleo13', 'ervleo13@nith.no', '', '2014-03-10 14:48:15', '', '0', 'ervleo13'); 
INSERT INTO `pj_users` VALUES ('3', 'snikim13', '$P$B1UaODjnUOolyz7F9cduL2UVPw3Uo00', 'snikim13', 'snikim13@nith.no', '', '2014-03-10 14:48:43', '', '0', 'snikim13'); 
INSERT INTO `pj_users` VALUES ('4', 'carlis13', '$P$BkxxGe6B.mOQvWLXPVprQuY.QL96rr/', 'carlis13', 'carlis13@nith.no', '', '2014-03-10 14:49:32', '', '0', 'carlis13'); 
INSERT INTO `pj_users` VALUES ('5', 'klemag13', '$P$BWHXXVRiVcTy0W7n8/pZihKCuimPRM/', 'klemag13', 'klemag13@nith.no', '', '2014-03-10 14:49:56', '', '0', 'klemag13'); 
INSERT INTO `pj_users` VALUES ('6', 'haneve13', '$P$BT.rA.Ah3kZcBz0tLwwqG26wLCpz1W1', 'haneve13', 'haneve13@nith.no', '', '2014-03-10 14:50:20', '', '0', 'haneve13'); 
INSERT INTO `pj_users` VALUES ('9', 'test', '$P$Bvz0jrN5r0k.0qURzgAYvzhAe2XT6o0', 'test', 'ksnippen@gmail.com', '', '2014-03-13 14:28:59', '', '0', 'test');
# --------------------------------------------------------


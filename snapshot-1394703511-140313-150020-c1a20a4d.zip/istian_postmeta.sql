CREATE TABLE IF NOT EXISTS `istian_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=106 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `istian_postmeta`;
 
INSERT INTO `istian_postmeta` VALUES ('1', '2', '_wp_page_template', 'template_fullwidth.php'); 
INSERT INTO `istian_postmeta` VALUES ('4', '5', '_wp_attached_file', '2013/02/Ilovestian-02.png'); 
INSERT INTO `istian_postmeta` VALUES ('5', '5', '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1408;s:6:"height";i:273;s:4:"file";s:25:"2013/02/Ilovestian-02.png";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Ilovestian-02-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:24:"Ilovestian-02-300x58.png";s:5:"width";i:300;s:6:"height";i:58;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:26:"Ilovestian-02-1024x198.png";s:5:"width";i:1024;s:6:"height";i:198;s:9:"mime-type";s:9:"image/png";}s:18:"product-thumbnails";a:4:{s:4:"file";s:24:"Ilovestian-02-148x28.png";s:5:"width";i:148;s:6:"height";i:28;s:9:"mime-type";s:9:"image/png";}s:15:"gold-thumbnails";a:4:{s:4:"file";s:22:"Ilovestian-02-31x6.png";s:5:"width";i:31;s:6:"height";i:6;s:9:"mime-type";s:9:"image/png";}s:24:"admin-product-thumbnails";a:4:{s:4:"file";s:22:"Ilovestian-02-38x7.png";s:5:"width";i:38;s:6:"height";i:7;s:9:"mime-type";s:9:"image/png";}s:27:"featured-product-thumbnails";a:4:{s:4:"file";s:24:"Ilovestian-02-425x82.png";s:5:"width";i:425;s:6:"height";i:82;s:9:"mime-type";s:9:"image/png";}s:23:"small-product-thumbnail";a:4:{s:4:"file";s:24:"Ilovestian-02-148x28.png";s:5:"width";i:148;s:6:"height";i:28;s:9:"mime-type";s:9:"image/png";}s:21:"medium-single-product";a:4:{s:4:"file";s:24:"Ilovestian-02-148x28.png";s:5:"width";i:148;s:6:"height";i:28;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `istian_postmeta` VALUES ('6', '6', '_wp_attached_file', '2013/02/Ilovestian2.png'); 
INSERT INTO `istian_postmeta` VALUES ('7', '6', '_wp_attachment_metadata', 'a:5:{s:5:"width";i:340;s:6:"height";i:66;s:4:"file";s:23:"2013/02/Ilovestian2.png";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"Ilovestian2-150x66.png";s:5:"width";i:150;s:6:"height";i:66;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:22:"Ilovestian2-300x58.png";s:5:"width";i:300;s:6:"height";i:58;s:9:"mime-type";s:9:"image/png";}s:18:"product-thumbnails";a:4:{s:4:"file";s:22:"Ilovestian2-148x28.png";s:5:"width";i:148;s:6:"height";i:28;s:9:"mime-type";s:9:"image/png";}s:15:"gold-thumbnails";a:4:{s:4:"file";s:20:"Ilovestian2-31x6.png";s:5:"width";i:31;s:6:"height";i:6;s:9:"mime-type";s:9:"image/png";}s:24:"admin-product-thumbnails";a:4:{s:4:"file";s:20:"Ilovestian2-38x7.png";s:5:"width";i:38;s:6:"height";i:7;s:9:"mime-type";s:9:"image/png";}s:23:"small-product-thumbnail";a:4:{s:4:"file";s:22:"Ilovestian2-148x28.png";s:5:"width";i:148;s:6:"height";i:28;s:9:"mime-type";s:9:"image/png";}s:21:"medium-single-product";a:4:{s:4:"file";s:22:"Ilovestian2-148x28.png";s:5:"width";i:148;s:6:"height";i:28;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `istian_postmeta` VALUES ('8', '7', '_wp_attached_file', '2013/02/Rose-Wallpaper-flowerdrop-24322607-1024-768.jpg'); 
INSERT INTO `istian_postmeta` VALUES ('9', '7', '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1024;s:6:"height";i:768;s:4:"file";s:55:"2013/02/Rose-Wallpaper-flowerdrop-24322607-1024-768.jpg";s:5:"sizes";a:8:{s:9:"thumbnail";a:4:{s:4:"file";s:55:"Rose-Wallpaper-flowerdrop-24322607-1024-768-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:55:"Rose-Wallpaper-flowerdrop-24322607-1024-768-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:18:"product-thumbnails";a:4:{s:4:"file";s:55:"Rose-Wallpaper-flowerdrop-24322607-1024-768-148x111.jpg";s:5:"width";i:148;s:6:"height";i:111;s:9:"mime-type";s:10:"image/jpeg";}s:15:"gold-thumbnails";a:4:{s:4:"file";s:53:"Rose-Wallpaper-flowerdrop-24322607-1024-768-31x23.jpg";s:5:"width";i:31;s:6:"height";i:23;s:9:"mime-type";s:10:"image/jpeg";}s:24:"admin-product-thumbnails";a:4:{s:4:"file";s:53:"Rose-Wallpaper-flowerdrop-24322607-1024-768-38x28.jpg";s:5:"width";i:38;s:6:"height";i:28;s:9:"mime-type";s:10:"image/jpeg";}s:27:"featured-product-thumbnails";a:4:{s:4:"file";s:55:"Rose-Wallpaper-flowerdrop-24322607-1024-768-286x215.jpg";s:5:"width";i:286;s:6:"height";i:215;s:9:"mime-type";s:10:"image/jpeg";}s:23:"small-product-thumbnail";a:4:{s:4:"file";s:55:"Rose-Wallpaper-flowerdrop-24322607-1024-768-148x111.jpg";s:5:"width";i:148;s:6:"height";i:111;s:9:"mime-type";s:10:"image/jpeg";}s:21:"medium-single-product";a:4:{s:4:"file";s:55:"Rose-Wallpaper-flowerdrop-24322607-1024-768-148x111.jpg";s:5:"width";i:148;s:6:"height";i:111;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `istian_postmeta` VALUES ('15', '19', 'total_sales', '0'); 
INSERT INTO `istian_postmeta` VALUES ('16', '19', '_regular_price', ''); 
INSERT INTO `istian_postmeta` VALUES ('14', '19', '_edit_lock', '1360869631:1'); 
INSERT INTO `istian_postmeta` VALUES ('13', '19', '_edit_last', '1'); 
INSERT INTO `istian_postmeta` VALUES ('17', '19', '_sale_price', ''); 
INSERT INTO `istian_postmeta` VALUES ('18', '19', '_tax_status', 'taxable'); 
INSERT INTO `istian_postmeta` VALUES ('19', '19', '_tax_class', ''); 
INSERT INTO `istian_postmeta` VALUES ('20', '19', '_visibility', 'visible'); 
INSERT INTO `istian_postmeta` VALUES ('21', '19', '_purchase_note', ''); 
INSERT INTO `istian_postmeta` VALUES ('22', '19', '_featured', 'no'); 
INSERT INTO `istian_postmeta` VALUES ('23', '19', '_weight', ''); 
INSERT INTO `istian_postmeta` VALUES ('24', '19', '_length', ''); 
INSERT INTO `istian_postmeta` VALUES ('25', '19', '_width', ''); 
INSERT INTO `istian_postmeta` VALUES ('26', '19', '_height', ''); 
INSERT INTO `istian_postmeta` VALUES ('27', '19', '_sku', ''); 
INSERT INTO `istian_postmeta` VALUES ('28', '19', '_product_attributes', 'a:0:{}'); 
INSERT INTO `istian_postmeta` VALUES ('29', '19', '_downloadable', 'no'); 
INSERT INTO `istian_postmeta` VALUES ('30', '19', '_virtual', 'no'); 
INSERT INTO `istian_postmeta` VALUES ('31', '19', '_sale_price_dates_from', ''); 
INSERT INTO `istian_postmeta` VALUES ('32', '19', '_sale_price_dates_to', ''); 
INSERT INTO `istian_postmeta` VALUES ('33', '19', '_price', ''); 
INSERT INTO `istian_postmeta` VALUES ('34', '19', '_stock', '10'); 
INSERT INTO `istian_postmeta` VALUES ('35', '19', '_stock_status', 'instock'); 
INSERT INTO `istian_postmeta` VALUES ('36', '19', '_backorders', 'no'); 
INSERT INTO `istian_postmeta` VALUES ('37', '19', '_manage_stock', 'yes'); 
INSERT INTO `istian_postmeta` VALUES ('38', '19', '_introduce_text_type', 'default'); 
INSERT INTO `istian_postmeta` VALUES ('39', '19', '_slideshow_category', '{s}'); 
INSERT INTO `istian_postmeta` VALUES ('40', '19', '_slideshow_number', '0'); 
INSERT INTO `istian_postmeta` VALUES ('41', '19', '_slideshow_type', 'nivo'); 
INSERT INTO `istian_postmeta` VALUES ('42', '19', '_layout', 'default'); 
INSERT INTO `istian_postmeta` VALUES ('43', '7', '_woocommerce_exclude_image', '0'); 
INSERT INTO `istian_postmeta` VALUES ('44', '6', '_woocommerce_exclude_image', '0'); 
INSERT INTO `istian_postmeta` VALUES ('45', '5', '_woocommerce_exclude_image', '0'); 
INSERT INTO `istian_postmeta` VALUES ('46', '21', '_wp_attached_file', '2013/02/istiancomingsoon.png'); 
INSERT INTO `istian_postmeta` VALUES ('49', '21', '_woocommerce_exclude_image', '0'); 
INSERT INTO `istian_postmeta` VALUES ('48', '21', '_wp_attachment_metadata', 'a:5:{s:5:"width";i:677;s:6:"height";i:377;s:4:"file";s:28:"2013/02/istiancomingsoon.png";s:5:"sizes";a:11:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"istiancomingsoon-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:28:"istiancomingsoon-300x167.png";s:5:"width";i:300;s:6:"height";i:167;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:26:"istiancomingsoon-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:28:"istiancomingsoon-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:28:"istiancomingsoon-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:18:"product-thumbnails";a:4:{s:4:"file";s:27:"istiancomingsoon-148x82.png";s:5:"width";i:148;s:6:"height";i:82;s:9:"mime-type";s:9:"image/png";}s:15:"gold-thumbnails";a:4:{s:4:"file";s:26:"istiancomingsoon-31x17.png";s:5:"width";i:31;s:6:"height";i:17;s:9:"mime-type";s:9:"image/png";}s:24:"admin-product-thumbnails";a:4:{s:4:"file";s:26:"istiancomingsoon-38x21.png";s:5:"width";i:38;s:6:"height";i:21;s:9:"mime-type";s:9:"image/png";}s:27:"featured-product-thumbnails";a:4:{s:4:"file";s:28:"istiancomingsoon-386x215.png";s:5:"width";i:386;s:6:"height";i:215;s:9:"mime-type";s:9:"image/png";}s:23:"small-product-thumbnail";a:4:{s:4:"file";s:27:"istiancomingsoon-148x82.png";s:5:"width";i:148;s:6:"height";i:82;s:9:"mime-type";s:9:"image/png";}s:21:"medium-single-product";a:4:{s:4:"file";s:27:"istiancomingsoon-148x82.png";s:5:"width";i:148;s:6:"height";i:82;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `istian_postmeta` VALUES ('50', '26', '_edit_last', '1'); 
INSERT INTO `istian_postmeta` VALUES ('51', '26', '_edit_lock', '1361450465:1'); 
INSERT INTO `istian_postmeta` VALUES ('52', '26', '_wpsc_price', '10'); 
INSERT INTO `istian_postmeta` VALUES ('53', '26', '_wpsc_special_price', '0'); 
INSERT INTO `istian_postmeta` VALUES ('54', '26', '_wpsc_sku', ''); 
INSERT INTO `istian_postmeta` VALUES ('55', '26', '_wpsc_stock', '10'); 
INSERT INTO `istian_postmeta` VALUES ('56', '26', '_wpsc_product_metadata', 'a:20:{s:25:"wpec_taxes_taxable_amount";s:0:"";s:13:"external_link";s:0:"";s:18:"external_link_text";s:0:"";s:20:"external_link_target";s:0:"";s:11:"no_shipping";i:1;s:6:"weight";d:0;s:11:"weight_unit";s:5:"pound";s:10:"dimensions";a:6:{s:6:"height";s:1:"0";s:11:"height_unit";s:2:"in";s:5:"width";s:1:"0";s:10:"width_unit";s:2:"in";s:6:"length";s:1:"0";s:11:"length_unit";s:2:"in";}s:8:"shipping";a:2:{s:5:"local";d:0;s:13:"international";d:0;}s:14:"merchant_notes";s:0:"";s:8:"engraved";i:0;s:23:"can_have_uploaded_image";i:0;s:15:"enable_comments";s:0:"";s:21:"notify_when_none_left";i:0;s:24:"unpublish_when_none_left";i:0;s:16:"quantity_limited";i:0;s:7:"special";i:0;s:17:"display_weight_as";s:5:"pound";s:16:"table_rate_price";a:2:{s:8:"quantity";a:0:{}s:11:"table_price";a:0:{}}s:17:"google_prohibited";i:0;}'); 
INSERT INTO `istian_postmeta` VALUES ('57', '26', '_wpsc_is_donation', '0'); 
INSERT INTO `istian_postmeta` VALUES ('58', '26', '_wpsc_currency', 'a:0:{}'); 
INSERT INTO `istian_postmeta` VALUES ('59', '28', '_wp_attached_file', '2013/02/slider.png'); 
INSERT INTO `istian_postmeta` VALUES ('60', '28', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1717;s:6:"height";i:671;s:4:"file";s:18:"2013/02/slider.png";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"slider-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:18:"slider-300x117.png";s:5:"width";i:300;s:6:"height";i:117;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:19:"slider-1024x400.png";s:5:"width";i:1024;s:6:"height";i:400;s:9:"mime-type";s:9:"image/png";}s:18:"product-thumbnails";a:4:{s:4:"file";s:17:"slider-148x57.png";s:5:"width";i:148;s:6:"height";i:57;s:9:"mime-type";s:9:"image/png";}s:15:"gold-thumbnails";a:4:{s:4:"file";s:16:"slider-31x12.png";s:5:"width";i:31;s:6:"height";i:12;s:9:"mime-type";s:9:"image/png";}s:24:"admin-product-thumbnails";a:4:{s:4:"file";s:16:"slider-38x14.png";s:5:"width";i:38;s:6:"height";i:14;s:9:"mime-type";s:9:"image/png";}s:27:"featured-product-thumbnails";a:4:{s:4:"file";s:18:"slider-425x166.png";s:5:"width";i:425;s:6:"height";i:166;s:9:"mime-type";s:9:"image/png";}s:23:"small-product-thumbnail";a:4:{s:4:"file";s:17:"slider-148x57.png";s:5:"width";i:148;s:6:"height";i:57;s:9:"mime-type";s:9:"image/png";}s:21:"medium-single-product";a:4:{s:4:"file";s:17:"slider-148x57.png";s:5:"width";i:148;s:6:"height";i:57;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:12:"custom_sizes";a:7:{s:7:"960x440";a:3:{s:4:"file";s:21:"28_slider-960x440.png";s:5:"width";i:960;s:6:"height";s:3:"440";}s:7:"960x240";a:3:{s:4:"file";s:21:"28_slider-960x240.png";s:5:"width";i:960;s:6:"height";s:3:"240";}s:7:"960x340";a:3:{s:4:"file";s:21:"28_slider-960x340.png";s:5:"width";i:960;s:6:"height";s:3:"340";}s:7:"960x360";a:3:{s:4:"file";s:21:"28_slider-960x360.png";s:5:"width";i:960;s:6:"height";s:3:"360";}s:7:"960x370";a:3:{s:4:"file";s:21:"28_slider-960x370.png";s:5:"width";i:960;s:6:"height";s:3:"370";}s:7:"960x375";a:3:{s:4:"file";s:21:"28_slider-960x375.png";s:5:"width";i:960;s:6:"height";s:3:"375";}s:7:"960x380";a:3:{s:4:"file";s:21:"28_slider-960x380.png";s:5:"width";i:960;s:6:"height";s:3:"380";}}}'); 
INSERT INTO `istian_postmeta` VALUES ('61', '27', '_thumbnail_id', '28'); 
INSERT INTO `istian_postmeta` VALUES ('62', '27', '_edit_last', '1'); 
INSERT INTO `istian_postmeta` VALUES ('63', '27', '_3d_pieces', '0'); 
INSERT INTO `istian_postmeta` VALUES ('64', '27', '_3d_time', '0'); 
INSERT INTO `istian_postmeta` VALUES ('65', '27', '_3d_delay', '0'); 
INSERT INTO `istian_postmeta` VALUES ('66', '27', '_3d_transition', 'default'); 
INSERT INTO `istian_postmeta` VALUES ('67', '27', '_3d_depthOffset', '0'); 
INSERT INTO `istian_postmeta` VALUES ('68', '27', '_3d_cubeDistance', '0'); 
INSERT INTO `istian_postmeta` VALUES ('69', '27', '_anything_type', 'image'); 
INSERT INTO `istian_postmeta` VALUES ('70', '27', '_image_caption_position', 'disable'); 
INSERT INTO `istian_postmeta` VALUES ('71', '27', '_sidebar_position', 'left'); 
INSERT INTO `istian_postmeta` VALUES ('72', '27', '_link_target', '_self'); 
INSERT INTO `istian_postmeta` VALUES ('73', '27', '_edit_lock', '1360879381:1'); 
INSERT INTO `istian_postmeta` VALUES ('74', '29', '_wp_attached_file', '2013/02/Skjermbilde-2013-02-19-kl.-17.19.42.png'); 
INSERT INTO `istian_postmeta` VALUES ('75', '29', '_wp_attachment_metadata', 'a:5:{s:5:"width";i:296;s:6:"height";i:272;s:4:"file";s:47:"2013/02/Skjermbilde-2013-02-19-kl.-17.19.42.png";s:5:"sizes";a:8:{s:9:"thumbnail";a:4:{s:4:"file";s:47:"Skjermbilde-2013-02-19-kl.-17.19.42-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:18:"product-thumbnails";a:4:{s:4:"file";s:47:"Skjermbilde-2013-02-19-kl.-17.19.42-148x136.png";s:5:"width";i:148;s:6:"height";i:136;s:9:"mime-type";s:9:"image/png";}s:15:"gold-thumbnails";a:4:{s:4:"file";s:45:"Skjermbilde-2013-02-19-kl.-17.19.42-31x28.png";s:5:"width";i:31;s:6:"height";i:28;s:9:"mime-type";s:9:"image/png";}s:24:"admin-product-thumbnails";a:4:{s:4:"file";s:45:"Skjermbilde-2013-02-19-kl.-17.19.42-38x34.png";s:5:"width";i:38;s:6:"height";i:34;s:9:"mime-type";s:9:"image/png";}s:27:"featured-product-thumbnails";a:4:{s:4:"file";s:47:"Skjermbilde-2013-02-19-kl.-17.19.42-233x215.png";s:5:"width";i:233;s:6:"height";i:215;s:9:"mime-type";s:9:"image/png";}s:23:"small-product-thumbnail";a:4:{s:4:"file";s:47:"Skjermbilde-2013-02-19-kl.-17.19.42-148x136.png";s:5:"width";i:148;s:6:"height";i:136;s:9:"mime-type";s:9:"image/png";}s:21:"medium-single-product";a:4:{s:4:"file";s:47:"Skjermbilde-2013-02-19-kl.-17.19.42-148x136.png";s:5:"width";i:148;s:6:"height";i:136;s:9:"mime-type";s:9:"image/png";}s:12:"wpsc-148x148";a:4:{s:4:"file";s:47:"Skjermbilde-2013-02-19-kl.-17.19.42-148x148.png";s:5:"width";i:148;s:6:"height";i:148;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `istian_postmeta` VALUES ('76', '26', '_thumbnail_id', '29'); 
INSERT INTO `istian_postmeta` VALUES ('77', '2', '_edit_lock', '1367058661:1'); 
INSERT INTO `istian_postmeta` VALUES ('78', '2', '_edit_last', '1'); 
INSERT INTO `istian_postmeta` VALUES ('79', '2', 'cp_pcontent_points_enable', '0'); 
INSERT INTO `istian_postmeta` VALUES ('80', '2', 'cp_pcontent_points', '1'); 
INSERT INTO `istian_postmeta` VALUES ('81', '2', '_introduce_text_type', 'default'); 
INSERT INTO `istian_postmeta` VALUES ('82', '2', '_slideshow_category', '{s}'); 
INSERT INTO `istian_postmeta` VALUES ('83', '2', '_slideshow_number', '0'); 
INSERT INTO `istian_postmeta` VALUES ('84', '2', '_slideshow_type', 'nivo'); 
INSERT INTO `istian_postmeta` VALUES ('85', '2', '_layout', 'default'); 
INSERT INTO `istian_postmeta` VALUES ('87', '36', 'rssmi_source_link', 'http://en.wikipedia.org/w/index.php?title=Category:Defunct_schools_in_Monmouthshire&amp;diff=552258601&amp;oldid=552258552'); 
INSERT INTO `istian_postmeta` VALUES ('89', '37', 'rssmi_source_link', 'http://en.wikipedia.org/w/index.php?title=Kashif_(1989_album)&amp;diff=552258598&amp;oldid=552243603'); 
INSERT INTO `istian_postmeta` VALUES ('91', '38', 'rssmi_source_link', 'http://en.wikipedia.org/w/index.php?title=Keith_Raffel&amp;diff=552258600&amp;oldid=552226113'); 
INSERT INTO `istian_postmeta` VALUES ('97', '41', 'rssmi_source_link', 'http://en.wikipedia.org/w/index.php?title=Alexia_Massalin&amp;diff=552258637&amp;oldid=516364108'); 
INSERT INTO `istian_postmeta` VALUES ('93', '39', 'rssmi_source_link', 'http://en.wikipedia.org/w/index.php?title=King_Henry_VIII_School_Abergavenny&amp;diff=552258599&amp;oldid=552258244'); 
INSERT INTO `istian_postmeta` VALUES ('95', '40', 'rssmi_source_link', 'http://en.wikipedia.org/w/index.php?title=WHo_write_an_article&amp;diff=552258597&amp;oldid=552257659'); 
INSERT INTO `istian_postmeta` VALUES ('99', '42', 'rssmi_source_link', 'http://en.wikipedia.org/w/index.php?title=R.A.M.O.N.E.S.&amp;diff=552258638&amp;oldid=549995487'); 
INSERT INTO `istian_postmeta` VALUES ('101', '43', 'rssmi_source_link', 'http://en.wikipedia.org/w/index.php?title=User_talk:Vlogigan&amp;diff=552258636&amp;oldid=552258593'); 
INSERT INTO `istian_postmeta` VALUES ('103', '44', 'rssmi_source_link', 'http://en.wikipedia.org/wiki/User:R3v07v3R'); 
INSERT INTO `istian_postmeta` VALUES ('105', '45', 'rssmi_source_link', 'http://en.wikipedia.org/w/index.php?title=User:Sfan00_IMG/CSD_log&amp;diff=552258635&amp;oldid=552258300');
# --------------------------------------------------------


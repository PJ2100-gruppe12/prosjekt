CREATE TABLE IF NOT EXISTS `wp_hfecommwpsc_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `object_type` varchar(24) NOT NULL DEFAULT 'cart_Item',
  `object_id` bigint(20) NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `object_type__meta_key` (`object_type`,`meta_key`),
  KEY `object_type__object_id__meta_key` (`object_type`,`object_id`,`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_hfecommwpsc_meta`;
 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('1', 'wpsc_category', '3', 'nicename', 'product-category'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('2', 'wpsc_category', '3', 'description', 'This is a description'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('3', 'wpsc_category', '3', 'image', ''); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('4', 'wpsc_category', '3', 'fee', '0'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('5', 'wpsc_category', '3', 'active', '1'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('6', 'wpsc_category', '3', 'order', '0'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('7', 'wpsc_category', '3', 'uses_billing_address', '0'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('8', 'wpsc_category', '3', 'target_market', ''); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('9', 'wpsc_category', '4', 'fee', '0'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('10', 'wpsc_category', '4', 'active', '1'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('11', 'wpsc_category', '4', 'order', '0'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('12', 'wpsc_category', '4', 'display_type', 'default'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('13', 'wpsc_category', '4', 'image_height', ''); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('14', 'wpsc_category', '4', 'image_width', ''); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('15', 'wpsc_category', '4', 'uses_billing_address', '0'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('16', 'wpsc_category', '4', 'target_market', ''); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('17', 'wpsc_category', '5', 'fee', '0'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('18', 'wpsc_category', '5', 'active', '1'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('19', 'wpsc_category', '5', 'order', '0'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('20', 'wpsc_category', '5', 'display_type', 'default'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('21', 'wpsc_category', '5', 'image_height', ''); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('22', 'wpsc_category', '5', 'image_width', ''); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('23', 'wpsc_category', '5', 'uses_billing_address', '0'); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('24', 'wpsc_category', '5', 'target_market', ''); 
INSERT INTO `wp_hfecommwpsc_meta` VALUES ('25', 'wpsc_cart_item', '1', 'sku', '');
# --------------------------------------------------------


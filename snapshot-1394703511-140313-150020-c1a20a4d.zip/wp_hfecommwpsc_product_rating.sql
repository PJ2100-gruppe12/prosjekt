CREATE TABLE IF NOT EXISTS `wp_hfecommwpsc_product_rating` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ipnum` varchar(30) NOT NULL DEFAULT '',
  `productid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rated` tinyint(1) NOT NULL DEFAULT '0',
  `time` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_hfecommwpsc_product_rating`;
 
INSERT INTO `wp_hfecommwpsc_product_rating` VALUES ('1', '84.215.188.38', '11', '5', '1351555172'); 
INSERT INTO `wp_hfecommwpsc_product_rating` VALUES ('2', '84.215.188.38', '9', '3', '1351555174'); 
INSERT INTO `wp_hfecommwpsc_product_rating` VALUES ('3', '84.215.188.38', '9', '5', '1351555176'); 
INSERT INTO `wp_hfecommwpsc_product_rating` VALUES ('4', '84.215.188.38', '11', '4', '1351555178');
# --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `nesconsultterms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `nesconsultterms`;
 
INSERT INTO `nesconsultterms` VALUES ('1', 'Uncategorized', 'uncategorized', '0'); 
INSERT INTO `nesconsultterms` VALUES ('2', 'Blogroll', 'blogroll', '0'); 
INSERT INTO `nesconsultterms` VALUES ('3', 'Menystruktur', 'menystruktur', '0'); 
INSERT INTO `nesconsultterms` VALUES ('4', 'Webutvikling', 'webutvikling', '0'); 
INSERT INTO `nesconsultterms` VALUES ('5', 'Logo', 'logo', '0'); 
INSERT INTO `nesconsultterms` VALUES ('6', 'Visittkort', 'visittkort', '0'); 
INSERT INTO `nesconsultterms` VALUES ('7', 'Portefølje', 'portefolje', '0'); 
INSERT INTO `nesconsultterms` VALUES ('8', 'HF', 'hf', '0'); 
INSERT INTO `nesconsultterms` VALUES ('9', 'BIBB', 'bibb', '0'); 
INSERT INTO `nesconsultterms` VALUES ('10', 'SFHV', 'sfhv', '0'); 
INSERT INTO `nesconsultterms` VALUES ('11', 'FC', 'fc', '0'); 
INSERT INTO `nesconsultterms` VALUES ('12', 'GA', 'ga', '0'); 
INSERT INTO `nesconsultterms` VALUES ('13', 'DICD', 'dicd', '0'); 
INSERT INTO `nesconsultterms` VALUES ('14', 'Front', 'front', '0'); 
INSERT INTO `nesconsultterms` VALUES ('15', 'Webutvikling', 'web', '0'); 
INSERT INTO `nesconsultterms` VALUES ('16', 'Visittkort', 'visitt', '0'); 
INSERT INTO `nesconsultterms` VALUES ('17', 'Profil', 'profil', '0'); 
INSERT INTO `nesconsultterms` VALUES ('18', 'Brosjyre / flyer', 'brosjyre', '0'); 
INSERT INTO `nesconsultterms` VALUES ('19', 'Mine prosjekter', 'prosjekter', '0'); 
INSERT INTO `nesconsultterms` VALUES ('20', 'Tom', 'tom', '0');
# --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `istian_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `istian_terms`;
 
INSERT INTO `istian_terms` VALUES ('1', 'Uncategorized', 'uncategorized', '0'); 
INSERT INTO `istian_terms` VALUES ('2', 'Blogroll', 'blogroll', '0'); 
INSERT INTO `istian_terms` VALUES ('3', 'simple', 'simple', '0'); 
INSERT INTO `istian_terms` VALUES ('4', 'grouped', 'grouped', '0'); 
INSERT INTO `istian_terms` VALUES ('5', 'variable', 'variable', '0'); 
INSERT INTO `istian_terms` VALUES ('6', 'external', 'external', '0'); 
INSERT INTO `istian_terms` VALUES ('7', 'pending', 'pending', '0'); 
INSERT INTO `istian_terms` VALUES ('8', 'failed', 'failed', '0'); 
INSERT INTO `istian_terms` VALUES ('9', 'on-hold', 'on-hold', '0'); 
INSERT INTO `istian_terms` VALUES ('10', 'processing', 'processing', '0'); 
INSERT INTO `istian_terms` VALUES ('11', 'completed', 'completed', '0'); 
INSERT INTO `istian_terms` VALUES ('12', 'refunded', 'refunded', '0'); 
INSERT INTO `istian_terms` VALUES ('13', 'cancelled', 'cancelled', '0'); 
INSERT INTO `istian_terms` VALUES ('14', 'Product Category', 'product-category', '0');
# --------------------------------------------------------


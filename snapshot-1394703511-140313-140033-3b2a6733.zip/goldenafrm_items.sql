CREATE TABLE IF NOT EXISTS `goldenafrm_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_key` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `ip` text,
  `form_id` int(11) DEFAULT NULL,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `parent_item_id` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_key` (`item_key`),
  KEY `form_id` (`form_id`),
  KEY `post_id` (`post_id`),
  KEY `user_id` (`user_id`),
  KEY `parent_item_id` (`parent_item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `goldenafrm_items`;
 
INSERT INTO `goldenafrm_items` VALUES ('1', 'x6gxxw', 'Shafi', 'a:2:{s:7:"browser";s:125:"Mozilla/5.0 (iPad; CPU OS 5_1 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9B176 Safari/7534.48.3";s:8:"referrer";s:49:"http://goldenacademy.nesconsult.no/kontakt-oss/\r\n";}', '46.9.118.236', '2', '0', '', '', '', '2012-04-06 22:24:10', '2012-04-06 22:24:10'); 
INSERT INTO `goldenafrm_items` VALUES ('2', 'h1c7vl', 'Sama Sadeghi', 'a:2:{s:7:"browser";s:108:"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11";s:8:"referrer";s:49:"http://goldenacademy.nesconsult.no/kontakt-oss/\r\n";}', '80.202.170.77', '2', '0', '', '', '', '2012-11-10 17:12:32', '2012-11-10 17:12:32'); 
INSERT INTO `goldenafrm_items` VALUES ('3', '1yr7u3', 'nazli rostamkhani', 'a:2:{s:7:"browser";s:70:"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)";s:8:"referrer";s:49:"http://goldenacademy.nesconsult.no/kontakt-oss/\r\n";}', '84.208.215.116', '2', '0', '', '', '', '2013-01-27 18:20:01', '2013-01-27 18:20:01'); 
INSERT INTO `goldenafrm_items` VALUES ('4', 'bxq91w', 'Thomas André Larssen', 'a:2:{s:7:"browser";s:109:"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22";s:8:"referrer";s:49:"http://goldenacademy.nesconsult.no/kontakt-oss/\r\n";}', '85.166.150.140', '2', '0', '', '', '', '2013-03-06 20:49:24', '2013-03-06 20:49:24'); 
INSERT INTO `goldenafrm_items` VALUES ('5', '18q89f', 'Shafi Adan', 'a:2:{s:7:"browser";s:125:"Mozilla/5.0 (iPad; CPU OS 5_1 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9B176 Safari/7534.48.3";s:8:"referrer";s:49:"http://goldenacademy.nesconsult.no/kontakt-oss/\r\n";}', '144.164.240.62', '2', '0', '', '', '', '2013-03-21 12:16:29', '2013-03-21 12:16:29'); 
INSERT INTO `goldenafrm_items` VALUES ('6', 'x30fgy', 'Shafi Adan', 'a:2:{s:7:"browser";s:125:"Mozilla/5.0 (iPad; CPU OS 5_1 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9B176 Safari/7534.48.3";s:8:"referrer";s:49:"http://goldenacademy.nesconsult.no/kontakt-oss/\r\n";}', '144.164.240.62', '2', '0', '', '', '', '2013-03-21 12:17:41', '2013-03-21 12:17:41');
# --------------------------------------------------------


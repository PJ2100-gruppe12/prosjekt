CREATE TABLE IF NOT EXISTS `wp_hfecommterm_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_hfecommterm_relationships`;
 
INSERT INTO `wp_hfecommterm_relationships` VALUES ('1', '2', '0'); 
INSERT INTO `wp_hfecommterm_relationships` VALUES ('2', '2', '0'); 
INSERT INTO `wp_hfecommterm_relationships` VALUES ('3', '2', '0'); 
INSERT INTO `wp_hfecommterm_relationships` VALUES ('4', '2', '0'); 
INSERT INTO `wp_hfecommterm_relationships` VALUES ('5', '2', '0'); 
INSERT INTO `wp_hfecommterm_relationships` VALUES ('6', '2', '0'); 
INSERT INTO `wp_hfecommterm_relationships` VALUES ('7', '2', '0'); 
INSERT INTO `wp_hfecommterm_relationships` VALUES ('1', '1', '0'); 
INSERT INTO `wp_hfecommterm_relationships` VALUES ('9', '7', '0'); 
INSERT INTO `wp_hfecommterm_relationships` VALUES ('9', '3', '0'); 
INSERT INTO `wp_hfecommterm_relationships` VALUES ('11', '8', '0'); 
INSERT INTO `wp_hfecommterm_relationships` VALUES ('11', '3', '0'); 
INSERT INTO `wp_hfecommterm_relationships` VALUES ('25', '20', '0'); 
INSERT INTO `wp_hfecommterm_relationships` VALUES ('25', '11', '0'); 
INSERT INTO `wp_hfecommterm_relationships` VALUES ('25', '7', '0');
# --------------------------------------------------------


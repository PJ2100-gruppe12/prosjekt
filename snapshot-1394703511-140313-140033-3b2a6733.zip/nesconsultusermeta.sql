CREATE TABLE IF NOT EXISTS `nesconsultusermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `nesconsultusermeta`;
 
INSERT INTO `nesconsultusermeta` VALUES ('1', '1', 'first_name', ''); 
INSERT INTO `nesconsultusermeta` VALUES ('2', '1', 'last_name', ''); 
INSERT INTO `nesconsultusermeta` VALUES ('3', '1', 'nickname', 'admin'); 
INSERT INTO `nesconsultusermeta` VALUES ('4', '1', 'description', ''); 
INSERT INTO `nesconsultusermeta` VALUES ('5', '1', 'rich_editing', 'true'); 
INSERT INTO `nesconsultusermeta` VALUES ('6', '1', 'comment_shortcuts', 'false'); 
INSERT INTO `nesconsultusermeta` VALUES ('7', '1', 'admin_color', 'fresh'); 
INSERT INTO `nesconsultusermeta` VALUES ('8', '1', 'use_ssl', '0'); 
INSERT INTO `nesconsultusermeta` VALUES ('9', '1', 'show_admin_bar_front', 'true'); 
INSERT INTO `nesconsultusermeta` VALUES ('10', '1', 'nesconsultcapabilities', 'a:1:{s:13:"administrator";s:1:"1";}'); 
INSERT INTO `nesconsultusermeta` VALUES ('11', '1', 'nesconsultuser_level', '10'); 
INSERT INTO `nesconsultusermeta` VALUES ('12', '1', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_customize_current_theme_link,wp340_choose_image_from_library,wp350_media,wp360_revisions'); 
INSERT INTO `nesconsultusermeta` VALUES ('13', '1', 'show_welcome_panel', '1'); 
INSERT INTO `nesconsultusermeta` VALUES ('14', '1', 'nesconsultdashboard_quick_press_last_post_id', '492'); 
INSERT INTO `nesconsultusermeta` VALUES ('15', '1', 'nesconsultuser-settings', 'hidetb=1&imgsize=full&editor=tinymce&wplink=1&align=center&urlbutton=file&libraryContent=browse'); 
INSERT INTO `nesconsultusermeta` VALUES ('16', '1', 'nesconsultuser-settings-time', '1390654184'); 
INSERT INTO `nesconsultusermeta` VALUES ('17', '1', 'managenav-menuscolumnshidden', 'a:1:{i:0;s:3:"xfn";}'); 
INSERT INTO `nesconsultusermeta` VALUES ('26', '1', 'closedpostboxes_page', 'a:0:{}'); 
INSERT INTO `nesconsultusermeta` VALUES ('18', '1', 'metaboxhidden_nav-menus', 'a:2:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";}'); 
INSERT INTO `nesconsultusermeta` VALUES ('19', '1', 'nav_menu_recently_edited', '20'); 
INSERT INTO `nesconsultusermeta` VALUES ('20', '1', 'closedpostboxes_portefolje', 'a:0:{}'); 
INSERT INTO `nesconsultusermeta` VALUES ('21', '1', 'metaboxhidden_portefolje', 'a:1:{i:0;s:10:"wpseo_meta";}'); 
INSERT INTO `nesconsultusermeta` VALUES ('22', '1', 'closedpostboxes_create-portfolio', 'a:0:{}'); 
INSERT INTO `nesconsultusermeta` VALUES ('23', '1', 'metaboxhidden_create-portfolio', 'a:2:{i:0;s:10:"wpseo_meta";i:1;s:7:"slugdiv";}'); 
INSERT INTO `nesconsultusermeta` VALUES ('24', '1', 'manageedit-portfoliocolumnshidden', 'a:4:{i:0;s:14:"wpseo-metadesc";i:1;s:13:"wpseo-focuskw";i:2;s:0:"";i:3;s:0:"";}'); 
INSERT INTO `nesconsultusermeta` VALUES ('25', '1', 'closedpostboxes_nav-menus', 'a:0:{}'); 
INSERT INTO `nesconsultusermeta` VALUES ('27', '1', 'metaboxhidden_page', 'a:6:{i:0;s:10:"wpseo_meta";i:1;s:10:"postcustom";i:2;s:11:"commentsdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";i:5;s:12:"revisionsdiv";}'); 
INSERT INTO `nesconsultusermeta` VALUES ('28', '1', 'closedpostboxes_portfolio', 'a:0:{}'); 
INSERT INTO `nesconsultusermeta` VALUES ('29', '1', 'metaboxhidden_portfolio', 'a:2:{i:0;s:10:"wpseo_meta";i:1;s:7:"slugdiv";}');
# --------------------------------------------------------


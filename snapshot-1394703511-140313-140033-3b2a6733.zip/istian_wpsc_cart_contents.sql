CREATE TABLE IF NOT EXISTS `istian_wpsc_cart_contents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `prodid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `purchaseid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `price` decimal(11,2) NOT NULL DEFAULT '0.00',
  `pnp` decimal(11,2) NOT NULL DEFAULT '0.00',
  `tax_charged` decimal(11,2) NOT NULL DEFAULT '0.00',
  `gst` decimal(11,2) NOT NULL DEFAULT '0.00',
  `quantity` int(10) unsigned NOT NULL DEFAULT '0',
  `donation` varchar(1) NOT NULL DEFAULT '0',
  `no_shipping` varchar(1) NOT NULL DEFAULT '0',
  `custom_message` text NOT NULL,
  `files` text NOT NULL,
  `meta` longtext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `istian_wpsc_cart_contents`;

# --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `wp_wponlinebackup_activity_log` (
  `activity_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `start` int(10) unsigned NOT NULL,
  `end` int(10) unsigned DEFAULT NULL,
  `comp` tinyint(2) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `media` tinyint(1) NOT NULL,
  `encrypted` tinyint(1) NOT NULL,
  `compressed` tinyint(1) NOT NULL,
  `errors` int(10) unsigned NOT NULL,
  `warnings` int(10) unsigned NOT NULL,
  `bsize` bigint(20) unsigned NOT NULL,
  `bcount` int(10) unsigned NOT NULL,
  `rsize` bigint(20) unsigned NOT NULL,
  `rcount` int(10) unsigned NOT NULL,
  PRIMARY KEY (`activity_id`),
  KEY `start` (`start`),
  KEY `end` (`end`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_wponlinebackup_activity_log`;

# --------------------------------------------------------


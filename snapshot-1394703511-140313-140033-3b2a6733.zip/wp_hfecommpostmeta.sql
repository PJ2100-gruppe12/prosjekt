CREATE TABLE IF NOT EXISTS `wp_hfecommpostmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_hfecommpostmeta`;
 
INSERT INTO `wp_hfecommpostmeta` VALUES ('5', '9', '_edit_last', '1'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('6', '9', '_edit_lock', '1351554365:1'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('7', '10', '_wp_attached_file', '2012/10/Attraksjon-lokalt-Steinsdalsfossen.jpeg'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('8', '10', '_wp_attachment_metadata', 'a:6:{s:5:"width";s:3:"320";s:6:"height";s:3:"368";s:14:"hwstring_small";s:22:"height=\'96\' width=\'83\'";s:4:"file";s:47:"2012/10/Attraksjon-lokalt-Steinsdalsfossen.jpeg";s:5:"sizes";a:10:{s:9:"thumbnail";a:3:{s:4:"file";s:47:"Attraksjon-lokalt-Steinsdalsfossen-150x150.jpeg";s:5:"width";s:3:"150";s:6:"height";s:3:"150";}s:6:"medium";a:3:{s:4:"file";s:47:"Attraksjon-lokalt-Steinsdalsfossen-260x300.jpeg";s:5:"width";s:3:"260";s:6:"height";s:3:"300";}s:18:"product-thumbnails";a:3:{s:4:"file";s:47:"Attraksjon-lokalt-Steinsdalsfossen-128x148.jpeg";s:5:"width";s:3:"128";s:6:"height";s:3:"148";}s:15:"gold-thumbnails";a:3:{s:4:"file";s:45:"Attraksjon-lokalt-Steinsdalsfossen-26x31.jpeg";s:5:"width";s:2:"26";s:6:"height";s:2:"31";}s:24:"admin-product-thumbnails";a:3:{s:4:"file";s:45:"Attraksjon-lokalt-Steinsdalsfossen-33x38.jpeg";s:5:"width";s:2:"33";s:6:"height";s:2:"38";}s:27:"featured-product-thumbnails";a:3:{s:4:"file";s:47:"Attraksjon-lokalt-Steinsdalsfossen-186x215.jpeg";s:5:"width";s:3:"186";s:6:"height";s:3:"215";}s:23:"small-product-thumbnail";a:3:{s:4:"file";s:47:"Attraksjon-lokalt-Steinsdalsfossen-128x148.jpeg";s:5:"width";s:3:"128";s:6:"height";s:3:"148";}s:21:"medium-single-product";a:3:{s:4:"file";s:47:"Attraksjon-lokalt-Steinsdalsfossen-128x148.jpeg";s:5:"width";s:3:"128";s:6:"height";s:3:"148";}s:12:"wpsc-148x148";a:3:{s:4:"file";s:47:"Attraksjon-lokalt-Steinsdalsfossen-148x148.jpeg";s:5:"width";s:3:"148";s:6:"height";s:3:"148";}s:10:"wpsc-31x31";a:3:{s:4:"file";s:45:"Attraksjon-lokalt-Steinsdalsfossen-31x31.jpeg";s:5:"width";s:2:"31";s:6:"height";s:2:"31";}}s:10:"image_meta";a:10:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";}}'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('9', '9', '_thumbnail_id', '10'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('10', '10', '_wpsc_custom_thumb_w', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('11', '10', '_wpsc_custom_thumb_h', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('12', '10', '_wpsc_selected_image_size', 'full'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('13', '9', '_wpsc_price', '0'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('14', '9', '_wpsc_special_price', '0'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('15', '9', '_wpsc_sku', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('16', '9', '_wpsc_stock', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('17', '9', '_wpsc_product_metadata', 'a:19:{s:25:"wpec_taxes_taxable_amount";s:0:"";s:13:"external_link";s:0:"";s:18:"external_link_text";s:0:"";s:20:"external_link_target";s:0:"";s:6:"weight";s:1:"0";s:11:"weight_unit";s:5:"pound";s:10:"dimensions";a:6:{s:6:"height";s:1:"0";s:11:"height_unit";s:2:"in";s:5:"width";s:2:"0 ";s:10:"width_unit";s:2:"in";s:6:"length";s:1:"0";s:11:"length_unit";s:2:"in";}s:8:"shipping";a:2:{s:5:"local";s:1:"0";s:13:"international";s:1:"0";}s:11:"no_shipping";s:1:"1";s:14:"merchant_notes";s:0:"";s:8:"engraved";s:1:"0";s:23:"can_have_uploaded_image";s:1:"0";s:15:"enable_comments";s:0:"";s:24:"unpublish_when_none_left";s:1:"0";s:16:"quantity_limited";s:1:"0";s:7:"special";s:1:"0";s:17:"display_weight_as";s:5:"pound";s:16:"table_rate_price";a:2:{s:8:"quantity";a:0:{}s:11:"table_price";a:0:{}}s:17:"google_prohibited";s:1:"0";}'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('18', '9', '_wpsc_is_donation', '0'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('19', '9', '_wpsc_currency', 'a:0:{}'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('20', '11', '_edit_last', '1'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('21', '11', '_edit_lock', '1351557443:1'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('22', '12', '_wp_attached_file', '2012/10/Selskap-Tunet-frå-nord.jpg'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('23', '12', '_wp_attachment_metadata', 'a:6:{s:5:"width";s:4:"1134";s:6:"height";s:3:"600";s:14:"hwstring_small";s:23:"height=\'67\' width=\'128\'";s:4:"file";s:35:"2012/10/Selskap-Tunet-frå-nord.jpg";s:5:"sizes";a:10:{s:9:"thumbnail";a:3:{s:4:"file";s:35:"Selskap-Tunet-frå-nord-150x150.jpg";s:5:"width";s:3:"150";s:6:"height";s:3:"150";}s:6:"medium";a:3:{s:4:"file";s:35:"Selskap-Tunet-frå-nord-300x158.jpg";s:5:"width";s:3:"300";s:6:"height";s:3:"158";}s:5:"large";a:3:{s:4:"file";s:36:"Selskap-Tunet-frå-nord-1024x541.jpg";s:5:"width";s:4:"1024";s:6:"height";s:3:"541";}s:18:"product-thumbnails";a:3:{s:4:"file";s:34:"Selskap-Tunet-frå-nord-148x78.jpg";s:5:"width";s:3:"148";s:6:"height";s:2:"78";}s:15:"gold-thumbnails";a:3:{s:4:"file";s:33:"Selskap-Tunet-frå-nord-31x16.jpg";s:5:"width";s:2:"31";s:6:"height";s:2:"16";}s:24:"admin-product-thumbnails";a:3:{s:4:"file";s:33:"Selskap-Tunet-frå-nord-38x20.jpg";s:5:"width";s:2:"38";s:6:"height";s:2:"20";}s:27:"featured-product-thumbnails";a:3:{s:4:"file";s:35:"Selskap-Tunet-frå-nord-406x215.jpg";s:5:"width";s:3:"406";s:6:"height";s:3:"215";}s:23:"small-product-thumbnail";a:3:{s:4:"file";s:34:"Selskap-Tunet-frå-nord-148x78.jpg";s:5:"width";s:3:"148";s:6:"height";s:2:"78";}s:21:"medium-single-product";a:3:{s:4:"file";s:34:"Selskap-Tunet-frå-nord-148x78.jpg";s:5:"width";s:3:"148";s:6:"height";s:2:"78";}s:12:"wpsc-148x148";a:3:{s:4:"file";s:35:"Selskap-Tunet-frå-nord-148x148.jpg";s:5:"width";s:3:"148";s:6:"height";s:3:"148";}}s:10:"image_meta";a:10:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";}}'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('24', '12', '_wpsc_custom_thumb_w', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('25', '12', '_wpsc_custom_thumb_h', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('26', '12', '_wpsc_selected_image_size', 'full'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('27', '11', '_thumbnail_id', '12'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('28', '11', '_wpsc_price', '0'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('29', '11', '_wpsc_special_price', '0'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('30', '11', '_wpsc_is_donation', '0'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('31', '11', '_wpsc_sku', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('32', '11', '_wpsc_stock', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('33', '11', '_wpsc_product_metadata', 'a:19:{s:25:"wpec_taxes_taxable_amount";s:0:"";s:13:"external_link";s:0:"";s:18:"external_link_text";s:0:"";s:20:"external_link_target";s:0:"";s:6:"weight";s:1:"0";s:11:"weight_unit";s:5:"pound";s:10:"dimensions";a:6:{s:6:"height";s:1:"0";s:11:"height_unit";s:2:"in";s:5:"width";s:5:"0    ";s:10:"width_unit";s:2:"in";s:6:"length";s:1:"0";s:11:"length_unit";s:2:"in";}s:8:"shipping";a:2:{s:5:"local";s:1:"0";s:13:"international";s:1:"0";}s:14:"merchant_notes";s:0:"";s:8:"engraved";s:1:"0";s:23:"can_have_uploaded_image";s:1:"0";s:15:"enable_comments";s:0:"";s:24:"unpublish_when_none_left";s:1:"0";s:11:"no_shipping";s:1:"0";s:16:"quantity_limited";s:1:"0";s:7:"special";s:1:"0";s:17:"display_weight_as";s:5:"pound";s:16:"table_rate_price";a:2:{s:8:"quantity";a:0:{}s:11:"table_price";a:0:{}}s:17:"google_prohibited";s:1:"0";}'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('34', '11', '_wpsc_currency', 'a:0:{}'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('36', '25', '_edit_last', '1'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('37', '25', '_edit_lock', '1351786864:1'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('38', '26', '_wp_attached_file', '2012/10/Attraksjon-lokalt-Steinsdalsfossen1.jpeg'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('39', '26', '_woocommerce_exclude_image', '0'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('40', '26', '_wp_attachment_metadata', 'a:6:{s:5:"width";s:3:"320";s:6:"height";s:3:"368";s:14:"hwstring_small";s:22:"height=\'96\' width=\'83\'";s:4:"file";s:48:"2012/10/Attraksjon-lokalt-Steinsdalsfossen1.jpeg";s:5:"sizes";a:11:{s:9:"thumbnail";a:3:{s:4:"file";s:48:"Attraksjon-lokalt-Steinsdalsfossen1-150x150.jpeg";s:5:"width";s:3:"150";s:6:"height";s:3:"150";}s:6:"medium";a:3:{s:4:"file";s:48:"Attraksjon-lokalt-Steinsdalsfossen1-260x300.jpeg";s:5:"width";s:3:"260";s:6:"height";s:3:"300";}s:18:"product-thumbnails";a:3:{s:4:"file";s:48:"Attraksjon-lokalt-Steinsdalsfossen1-128x148.jpeg";s:5:"width";s:3:"128";s:6:"height";s:3:"148";}s:15:"gold-thumbnails";a:3:{s:4:"file";s:46:"Attraksjon-lokalt-Steinsdalsfossen1-26x31.jpeg";s:5:"width";s:2:"26";s:6:"height";s:2:"31";}s:24:"admin-product-thumbnails";a:3:{s:4:"file";s:46:"Attraksjon-lokalt-Steinsdalsfossen1-33x38.jpeg";s:5:"width";s:2:"33";s:6:"height";s:2:"38";}s:27:"featured-product-thumbnails";a:3:{s:4:"file";s:48:"Attraksjon-lokalt-Steinsdalsfossen1-186x215.jpeg";s:5:"width";s:3:"186";s:6:"height";s:3:"215";}s:23:"small-product-thumbnail";a:3:{s:4:"file";s:48:"Attraksjon-lokalt-Steinsdalsfossen1-128x148.jpeg";s:5:"width";s:3:"128";s:6:"height";s:3:"148";}s:21:"medium-single-product";a:3:{s:4:"file";s:48:"Attraksjon-lokalt-Steinsdalsfossen1-128x148.jpeg";s:5:"width";s:3:"128";s:6:"height";s:3:"148";}s:14:"shop_thumbnail";a:3:{s:4:"file";s:46:"Attraksjon-lokalt-Steinsdalsfossen1-90x90.jpeg";s:5:"width";s:2:"90";s:6:"height";s:2:"90";}s:12:"shop_catalog";a:3:{s:4:"file";s:48:"Attraksjon-lokalt-Steinsdalsfossen1-150x150.jpeg";s:5:"width";s:3:"150";s:6:"height";s:3:"150";}s:11:"shop_single";a:3:{s:4:"file";s:48:"Attraksjon-lokalt-Steinsdalsfossen1-300x300.jpeg";s:5:"width";s:3:"300";s:6:"height";s:3:"300";}}s:10:"image_meta";a:10:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";}}'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('41', '25', '_thumbnail_id', '26'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('76', '25', 'Veibeskrivelse', '<a href="https://maps.google.com/maps?saddr=Hardanger+Feriesenter+AS,+Hardangerfjordvegen+341,+Norheimsund,+Norway&daddr=Steinsdalsfossen,+Kvam,+Norway&hl=en&sll=60.369432,6.146604&sspn=0.056354,0.181618&geocode=Fc0kmQMd-nReACHVjRjQfgbiKymj3Lav8jM8RjHVjRjQfgbiKw%3BFWMvmQMdXx9dACnvlGAxNTQ8RjEYbi5kUXrHaw&oq=harda&doflg=ptm&mra=ltm&t=m&z=14">Åpne Google Maps</a>'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('43', '25', '_regular_price', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('44', '25', '_sale_price', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('45', '25', '_tax_status', 'none'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('46', '25', '_tax_class', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('47', '25', '_visibility', 'visible'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('48', '25', '_purchase_note', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('49', '25', '_featured', 'no'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('50', '25', '_weight', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('51', '25', '_length', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('52', '25', '_width', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('53', '25', '_height', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('54', '25', '_sku', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('55', '25', '_product_attributes', 'a:0:{}'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('56', '25', '_downloadable', 'no'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('57', '25', '_virtual', 'no'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('58', '25', '_sale_price_dates_from', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('59', '25', '_sale_price_dates_to', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('60', '25', '_price', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('61', '25', '_stock_status', 'instock'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('62', '25', '_min_variation_price', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('63', '25', '_max_variation_price', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('64', '25', '_min_variation_regular_price', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('65', '25', '_max_variation_regular_price', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('66', '25', '_min_variation_sale_price', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('67', '25', '_max_variation_sale_price', ''); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('68', '25', '_default_attributes', 'a:0:{}'); 
INSERT INTO `wp_hfecommpostmeta` VALUES ('77', '25', 'total_sales', '0');
# --------------------------------------------------------


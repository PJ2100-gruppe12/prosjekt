CREATE TABLE IF NOT EXISTS `istian_wpsc_checkout_forms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `type` varchar(64) NOT NULL DEFAULT '',
  `mandatory` varchar(1) NOT NULL DEFAULT '0',
  `display_log` char(1) NOT NULL DEFAULT '0',
  `default` varchar(128) NOT NULL DEFAULT '0',
  `active` varchar(1) NOT NULL DEFAULT '1',
  `checkout_order` int(10) unsigned NOT NULL DEFAULT '0',
  `unique_name` varchar(255) NOT NULL DEFAULT '',
  `options` longtext NOT NULL,
  `checkout_set` varchar(64) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `checkout_order` (`checkout_order`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `istian_wpsc_checkout_forms`;
 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('1', 'Your billing/contact details', 'heading', '0', '0', '1', '1', '0', '', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('2', 'First Name', 'text', '1', '1', '1', '1', '1', 'billingfirstname', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('3', 'Last Name', 'text', '1', '1', '1', '1', '2', 'billinglastname', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('4', 'Address', 'address', '1', '0', '1', '1', '3', 'billingaddress', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('5', 'City', 'city', '1', '0', '1', '1', '4', 'billingcity', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('6', 'State', 'text', '0', '0', '1', '1', '5', 'billingstate', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('7', 'Country', 'country', '1', '0', '1', '1', '6', 'billingcountry', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('8', 'Postal Code', 'text', '0', '0', '1', '1', '7', 'billingpostcode', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('9', 'Email', 'email', '1', '1', '1', '1', '9', 'billingemail', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('10', 'Shipping Address', 'heading', '0', '0', '1', '1', '10', 'delivertoafriend', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('11', 'First Name', 'text', '0', '0', '1', '1', '11', 'shippingfirstname', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('12', 'Last Name', 'text', '0', '0', '1', '1', '12', 'shippinglastname', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('13', 'Address', 'address', '0', '0', '1', '1', '13', 'shippingaddress', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('14', 'City', 'city', '0', '0', '1', '1', '14', 'shippingcity', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('15', 'State', 'text', '0', '0', '1', '1', '15', 'shippingstate', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('16', 'Country', 'delivery_country', '0', '0', '1', '1', '16', 'shippingcountry', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('17', 'Postal Code', 'text', '0', '0', '1', '1', '17', 'shippingpostcode', '', '0'); 
INSERT INTO `istian_wpsc_checkout_forms` VALUES ('18', 'Phone', 'text', '1', '0', '', '1', '8', 'billingphone', '', '0');
# --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `goldenawponlinebackup_activity_log` (
  `activity_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `start` int(10) unsigned NOT NULL,
  `end` int(10) unsigned DEFAULT NULL,
  `comp` tinyint(2) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `media` tinyint(1) NOT NULL,
  `encrypted` tinyint(1) NOT NULL,
  `compressed` tinyint(1) NOT NULL,
  `errors` int(10) unsigned NOT NULL,
  `warnings` int(10) unsigned NOT NULL,
  `bsize` bigint(20) unsigned NOT NULL,
  `bcount` int(10) unsigned NOT NULL,
  `rsize` bigint(20) unsigned NOT NULL,
  `rcount` int(10) unsigned NOT NULL,
  PRIMARY KEY (`activity_id`),
  KEY `start` (`start`),
  KEY `end` (`end`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `goldenawponlinebackup_activity_log`;
 
INSERT INTO `goldenawponlinebackup_activity_log` VALUES ('1', '1363871218', '1363871258', '1', '0', '1', '0', '1', '0', '0', '27999134', '2022', '45805285', '2022'); 
INSERT INTO `goldenawponlinebackup_activity_log` VALUES ('2', '1363950366', '1363950421', '1', '0', '1', '0', '1', '0', '0', '34763081', '2553', '55715904', '2553');
# --------------------------------------------------------


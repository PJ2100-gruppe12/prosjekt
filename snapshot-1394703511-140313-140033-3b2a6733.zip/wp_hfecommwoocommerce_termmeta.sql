CREATE TABLE IF NOT EXISTS `wp_hfecommwoocommerce_termmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `woocommerce_term_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_hfecommwoocommerce_termmeta`;
 
INSERT INTO `wp_hfecommwoocommerce_termmeta` VALUES ('1', '3', 'order', '3'); 
INSERT INTO `wp_hfecommwoocommerce_termmeta` VALUES ('2', '3', 'thumbnail_id', ''); 
INSERT INTO `wp_hfecommwoocommerce_termmeta` VALUES ('3', '5', 'order', '2'); 
INSERT INTO `wp_hfecommwoocommerce_termmeta` VALUES ('4', '5', 'thumbnail_id', ''); 
INSERT INTO `wp_hfecommwoocommerce_termmeta` VALUES ('5', '4', 'order', '1'); 
INSERT INTO `wp_hfecommwoocommerce_termmeta` VALUES ('6', '4', 'thumbnail_id', ''); 
INSERT INTO `wp_hfecommwoocommerce_termmeta` VALUES ('7', '20', 'order', '1');
# --------------------------------------------------------


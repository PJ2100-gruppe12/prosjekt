CREATE TABLE IF NOT EXISTS `ska_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `ska_posts`;
 
INSERT INTO `ska_posts` VALUES ('1', '1', '2013-04-08 10:57:09', '2013-04-08 10:57:09', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2013-04-08 10:57:09', '2013-04-08 10:57:09', '', '0', 'http://forberedt.nesconsult.no/?p=1', '0', 'post', '', '1'); 
INSERT INTO `ska_posts` VALUES ('4', '1', '2013-04-08 12:12:20', '2013-04-08 11:12:20', 'http://forberedt.nesconsult.no/wp-content/uploads/2013/04/cropped-forberedt.no_.png', 'cropped-forberedt.no_.png', '', 'inherit', 'closed', 'open', '', 'cropped-forberedt-no_-png', '', '', '2013-04-08 12:12:20', '2013-04-08 11:12:20', '', '0', 'http://forberedt.nesconsult.no/wp-content/uploads/2013/04/cropped-forberedt.no_.png', '0', 'attachment', 'image/png', '0'); 
INSERT INTO `ska_posts` VALUES ('5', '1', '2013-04-08 12:14:39', '2013-04-08 11:14:39', '', 'Førerkort', '', 'publish', 'open', 'open', '', 'forerkort', '', '', '2013-04-08 12:16:34', '2013-04-08 11:16:34', '', '0', 'http://forberedt.nesconsult.no/?page_id=5', '0', 'page', '', '0'); 
INSERT INTO `ska_posts` VALUES ('6', '1', '2013-04-08 12:14:14', '2013-04-08 11:14:14', '', 'Førerkort', '', 'inherit', 'open', 'open', '', '5-revision', '', '', '2013-04-08 12:14:14', '2013-04-08 11:14:14', '', '5', 'http://forberedt.nesconsult.no/5-revision/', '0', 'revision', '', '0'); 
INSERT INTO `ska_posts` VALUES ('7', '1', '2013-04-08 12:14:52', '2013-04-08 11:14:52', '', 'VGS-Pensum', '', 'publish', 'open', 'open', '', 'vgs-pensum', '', '', '2013-04-08 12:16:41', '2013-04-08 11:16:41', '', '0', 'http://forberedt.nesconsult.no/?page_id=7', '0', 'page', '', '0'); 
INSERT INTO `ska_posts` VALUES ('8', '1', '2013-04-08 12:15:15', '2013-04-08 11:15:15', '', 'Ex phil / Ex fac', '', 'publish', 'open', 'open', '', 'ex-phil-ex-fac', '', '', '2013-04-08 12:16:21', '2013-04-08 11:16:21', '', '0', 'http://forberedt.nesconsult.no/?page_id=8', '0', 'page', '', '0'); 
INSERT INTO `ska_posts` VALUES ('10', '1', '2013-04-08 12:15:15', '2013-04-08 11:15:15', '', 'Ex phil / Ex fac', '', 'inherit', 'open', 'open', '', '8-revision', '', '', '2013-04-08 12:15:15', '2013-04-08 11:15:15', '', '8', 'http://forberedt.nesconsult.no/8-revision/', '0', 'revision', '', '0'); 
INSERT INTO `ska_posts` VALUES ('11', '1', '2013-04-08 12:14:39', '2013-04-08 11:14:39', '', 'Førerkort', '', 'inherit', 'open', 'open', '', '5-revision-2', '', '', '2013-04-08 12:14:39', '2013-04-08 11:14:39', '', '5', 'http://forberedt.nesconsult.no/5-revision-2/', '0', 'revision', '', '0'); 
INSERT INTO `ska_posts` VALUES ('12', '1', '2013-04-08 12:14:52', '2013-04-08 11:14:52', '', 'VGS-Pensum', '', 'inherit', 'open', 'open', '', '7-revision', '', '', '2013-04-08 12:14:52', '2013-04-08 11:14:52', '', '7', 'http://forberedt.nesconsult.no/7-revision/', '0', 'revision', '', '0');
# --------------------------------------------------------


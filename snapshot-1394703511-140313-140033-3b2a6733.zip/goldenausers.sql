CREATE TABLE IF NOT EXISTS `goldenausers` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `goldenausers`;
 
INSERT INTO `goldenausers` VALUES ('1', 'admin', '$P$B2.Psyv0VzHsOphSofS1QX0FANJXZJ0', 'admin', 'post@nesconsult.no', '', '2012-04-03 15:25:15', '', '0', 'admin'); 
INSERT INTO `goldenausers` VALUES ('2', 'celine', '$P$BtDf2MXc2ytbST51LG40T..Qbz.wYc/', 'celine', 'celine91@live.no', '', '2012-04-20 13:00:45', '', '0', 'celine'); 
INSERT INTO `goldenausers` VALUES ('3', 'seo-rune', '$P$B1MTtJmSNJn.inTchcRYbGH19SRmsX0', 'seo-rune', 'rune@webfirmaet.no', '', '2013-03-21 13:03:42', '', '0', 'seo-rune');
# --------------------------------------------------------


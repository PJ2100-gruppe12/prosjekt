CREATE TABLE IF NOT EXISTS `nesconsultkingsize_photos` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `album` bigint(20) NOT NULL,
  `ext` tinytext NOT NULL,
  `name` text NOT NULL,
  `description` longtext NOT NULL,
  `p_order` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
TRUNCATE TABLE `nesconsultkingsize_photos`;

# --------------------------------------------------------


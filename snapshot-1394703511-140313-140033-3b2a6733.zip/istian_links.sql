CREATE TABLE IF NOT EXISTS `istian_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `istian_links`;
 
INSERT INTO `istian_links` VALUES ('1', 'http://codex.wordpress.org/', 'Documentation', '', '', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', ''); 
INSERT INTO `istian_links` VALUES ('2', 'http://wordpress.org/news/', 'WordPress Blog', '', '', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', 'http://wordpress.org/news/feed/'); 
INSERT INTO `istian_links` VALUES ('3', 'http://wordpress.org/support/', 'Support Forums', '', '', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', ''); 
INSERT INTO `istian_links` VALUES ('4', 'http://wordpress.org/extend/plugins/', 'Plugins', '', '', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', ''); 
INSERT INTO `istian_links` VALUES ('5', 'http://wordpress.org/extend/themes/', 'Themes', '', '', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', ''); 
INSERT INTO `istian_links` VALUES ('6', 'http://wordpress.org/support/forum/requests-and-feedback', 'Feedback', '', '', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', ''); 
INSERT INTO `istian_links` VALUES ('7', 'http://planet.wordpress.org/', 'WordPress Planet', '', '', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', '');
# --------------------------------------------------------


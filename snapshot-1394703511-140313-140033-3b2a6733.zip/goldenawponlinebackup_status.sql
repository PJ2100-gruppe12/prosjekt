CREATE TABLE IF NOT EXISTS `goldenawponlinebackup_status` (
  `status` tinyint(1) unsigned NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `counter` int(10) unsigned NOT NULL,
  `stop_user` varchar(255) NOT NULL,
  `progress` blob NOT NULL,
  PRIMARY KEY (`status`,`time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
TRUNCATE TABLE `goldenawponlinebackup_status`;
 
INSERT INTO `goldenawponlinebackup_status` VALUES ('0', '1363950421', '389', '', 'a:28:{s:7:"version";s:6:"2.2.18";s:10:"start_time";i:1363950366;s:10:"initialise";i:0;s:11:"activity_id";i:2;s:4:"comp";i:1;s:7:"message";s:26:"Updating backup journal...";s:6:"config";a:4:{s:15:"backup_database";b:1;s:17:"backup_filesystem";b:1;s:6:"target";s:8:"download";s:8:"email_to";s:0:"";}s:4:"type";i:0;s:15:"frozen_timeouts";i:0;s:12:"last_timeout";N;s:17:"progress_timeouts";i:0;s:6:"errors";i:0;s:8:"warnings";i:0;s:8:"cleanups";a:0:{}s:8:"jobcount";i:143;s:7:"jobdone";i:143;s:8:"rotation";i:1;s:4:"file";N;s:8:"file_set";a:6:{s:4:"file";s:112:"/customers/e/e/d/nesconsult.no/httpd.www/goldenacademy/wp-content/plugins/wponlinebackup/tmp/full/backup.zip.php";s:6:"offset";i:47;s:4:"size";i:34763081;s:5:"files";i:2553;s:10:"compressed";b:1;s:9:"encrypted";b:0;}s:6:"rcount";i:2553;s:5:"rsize";i:55715904;s:5:"ticks";i:0;s:12:"update_ticks";i:100;s:19:"revert_update_ticks";i:0;s:13:"tick_progress";a:2:{i:0;b:0;i:1;i:0;}s:8:"performs";i:4;s:5:"nonce";s:0:"";s:3:"bsn";i:0;}');
# --------------------------------------------------------


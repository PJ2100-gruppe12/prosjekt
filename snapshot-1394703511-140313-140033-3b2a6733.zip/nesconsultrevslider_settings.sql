CREATE TABLE IF NOT EXISTS `nesconsultrevslider_settings` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `general` text NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `nesconsultrevslider_settings`;

# --------------------------------------------------------


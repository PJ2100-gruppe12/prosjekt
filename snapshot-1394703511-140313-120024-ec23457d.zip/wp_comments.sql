CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_comments`;
 
INSERT INTO `wp_comments` VALUES ('1', '1', 'Mr WordPress', '', 'http://wordpress.org/', '', '2012-11-06 20:59:41', '2012-11-06 20:59:41', 'Hi, this is a comment.<br />To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', '0', '1', '', '', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('2', '820', 'WooCommerce', 'woocommerce@gunnarscorporate.com', '', '', '2013-02-22 19:40:09', '2013-02-22 18:40:09', 'IPN payment completed', '0', '1', 'WooCommerce', 'order_note', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('3', '820', 'WooCommerce', 'woocommerce@gunnarscorporate.com', '', '', '2013-02-22 19:40:10', '2013-02-22 18:40:10', 'Order status changed from pending to processing.', '0', '1', 'WooCommerce', 'order_note', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('4', '905', 'WooCommerce', 'woocommerce@gunnarscorporate.com', '', '', '2013-02-24 16:55:21', '2013-02-24 15:55:21', 'Payment to be made upon delivery. Order status changed from pending to on-hold.', '0', '1', 'WooCommerce', 'order_note', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('5', '906', 'WooCommerce', 'woocommerce@gunnarscorporate.com', '', '', '2013-02-24 16:59:05', '2013-02-24 15:59:05', 'Payment to be made upon delivery. Order status changed from pending to on-hold.', '0', '1', 'WooCommerce', 'order_note', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('6', '929', 'WooCommerce', 'woocommerce@gunnarscorporate.com', '', '', '2013-02-25 19:23:02', '2013-02-25 18:23:02', 'Payment to be made upon delivery. Order status changed from pending to on-hold.', '0', '1', 'WooCommerce', 'order_note', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('7', '905', 'WooCommerce', 'woocommerce@gunnarscorporate.com', '', '', '2013-03-04 23:02:00', '2013-03-04 22:02:00', 'Order status changed from on-hold to processing.', '0', '1', 'WooCommerce', 'order_note', '0', '0');
# --------------------------------------------------------


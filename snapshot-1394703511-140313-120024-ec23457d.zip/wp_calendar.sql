CREATE TABLE IF NOT EXISTS `wp_calendar` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_begin` date NOT NULL,
  `event_end` date NOT NULL,
  `event_title` varchar(30) COLLATE utf8_danish_ci NOT NULL,
  `event_desc` text COLLATE utf8_danish_ci NOT NULL,
  `event_time` time DEFAULT NULL,
  `event_recur` char(1) COLLATE utf8_danish_ci DEFAULT NULL,
  `event_repeats` int(3) DEFAULT NULL,
  `event_author` bigint(20) unsigned DEFAULT NULL,
  `event_category` bigint(20) unsigned NOT NULL DEFAULT '1',
  `event_link` text COLLATE utf8_danish_ci,
  PRIMARY KEY (`event_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci;
TRUNCATE TABLE `wp_calendar`;
 
INSERT INTO `wp_calendar` VALUES ('1', '2014-03-14', '2014-03-14', 'Fest!', 'Sosialutvalget har fest i #fuBar!', '16:00:00', 'S', '0', '1', '1', 'http://www.google.com');
# --------------------------------------------------------


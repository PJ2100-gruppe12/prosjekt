CREATE TABLE IF NOT EXISTS `goldenaterm_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `goldenaterm_relationships`;
 
INSERT INTO `goldenaterm_relationships` VALUES ('1', '2', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('2', '2', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('3', '2', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('4', '2', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('5', '2', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('6', '2', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('7', '2', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('487', '3', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('84', '3', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('47', '3', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('45', '3', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('62', '3', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('61', '3', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('110', '1', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('110', '4', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('283', '3', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('488', '3', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('492', '3', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('493', '3', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('495', '1', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('535', '3', '0'); 
INSERT INTO `goldenaterm_relationships` VALUES ('536', '3', '0');
# --------------------------------------------------------


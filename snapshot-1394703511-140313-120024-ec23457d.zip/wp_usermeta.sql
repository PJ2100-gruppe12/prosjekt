CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_usermeta`;
 
INSERT INTO `wp_usermeta` VALUES ('1', '1', 'first_name', 'Solveig Maria Nes'); 
INSERT INTO `wp_usermeta` VALUES ('2', '1', 'last_name', 'Solveig Maria Nes'); 
INSERT INTO `wp_usermeta` VALUES ('3', '1', 'nickname', 'admin'); 
INSERT INTO `wp_usermeta` VALUES ('4', '1', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('5', '1', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('6', '1', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('7', '1', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('8', '1', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('9', '1', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('10', '1', 'wp_capabilities', 'a:1:{s:13:"administrator";s:1:"1";}'); 
INSERT INTO `wp_usermeta` VALUES ('11', '1', 'wp_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES ('12', '1', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_customize_current_theme_link,wp350_media'); 
INSERT INTO `wp_usermeta` VALUES ('13', '1', 'show_welcome_panel', '1'); 
INSERT INTO `wp_usermeta` VALUES ('14', '1', 'wp_dashboard_quick_press_last_post_id', '930'); 
INSERT INTO `wp_usermeta` VALUES ('15', '1', 'wp_user-settings', 'imgsize=large&editor=tinymce&hidetb=1&align=none&urlbutton=none&libraryContent=browse&ed_size=643&wplink=1'); 
INSERT INTO `wp_usermeta` VALUES ('16', '1', 'wp_user-settings-time', '1361722884'); 
INSERT INTO `wp_usermeta` VALUES ('17', '1', 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'); 
INSERT INTO `wp_usermeta` VALUES ('18', '1', 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:13:"add-portfolio";i:2;s:12:"add-post_tag";}'); 
INSERT INTO `wp_usermeta` VALUES ('19', '1', 'nav_menu_recently_edited', '38'); 
INSERT INTO `wp_usermeta` VALUES ('20', '2', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('21', '2', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('22', '2', 'nickname', 'preview'); 
INSERT INTO `wp_usermeta` VALUES ('23', '2', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('24', '2', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('25', '2', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('26', '2', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('27', '2', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('28', '2', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('29', '2', 'wp_capabilities', 'a:1:{s:10:"subscriber";s:1:"1";}'); 
INSERT INTO `wp_usermeta` VALUES ('30', '2', 'wp_user_level', '0'); 
INSERT INTO `wp_usermeta` VALUES ('31', '2', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link'); 
INSERT INTO `wp_usermeta` VALUES ('32', '2', 'aim', ''); 
INSERT INTO `wp_usermeta` VALUES ('33', '2', 'yim', ''); 
INSERT INTO `wp_usermeta` VALUES ('34', '2', 'jabber', ''); 
INSERT INTO `wp_usermeta` VALUES ('35', '1', 'closedpostboxes_page', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('36', '1', 'metaboxhidden_page', 'a:5:{i:0;s:10:"postcustom";i:1;s:11:"commentsdiv";i:2;s:7:"slugdiv";i:3;s:9:"authordiv";i:4;s:12:"revisionsdiv";}'); 
INSERT INTO `wp_usermeta` VALUES ('37', '2', 'wp_user-settings', 'mfold=o'); 
INSERT INTO `wp_usermeta` VALUES ('38', '2', 'wp_user-settings-time', '1353601138'); 
INSERT INTO `wp_usermeta` VALUES ('39', '3', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('40', '3', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('41', '3', 'nickname', 'guru'); 
INSERT INTO `wp_usermeta` VALUES ('42', '3', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('43', '3', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('44', '3', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('45', '3', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('46', '3', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('47', '3', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('48', '3', 'wp_capabilities', 'a:1:{s:13:"administrator";s:1:"1";}'); 
INSERT INTO `wp_usermeta` VALUES ('49', '3', 'wp_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES ('50', '3', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link'); 
INSERT INTO `wp_usermeta` VALUES ('51', '1', 'closedpostboxes_product', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('52', '1', 'metaboxhidden_product', 'a:1:{i:0;s:7:"slugdiv";}'); 
INSERT INTO `wp_usermeta` VALUES ('53', '1', 'meta-box-order_product', 'a:3:{s:4:"side";s:57:"submitdiv,product_catdiv,tagsdiv-product_tag,postimagediv";s:6:"normal";s:67:"woocommerce-product-data,postexcerpt,postcustom,slugdiv,commentsdiv";s:8:"advanced";s:0:"";}'); 
INSERT INTO `wp_usermeta` VALUES ('54', '1', 'screen_layout_product', '2'); 
INSERT INTO `wp_usermeta` VALUES ('56', '1', 'edit_page_per_page', '40'); 
INSERT INTO `wp_usermeta` VALUES ('57', '4', 'first_name', 'Anders Lima'); 
INSERT INTO `wp_usermeta` VALUES ('58', '4', 'last_name', 'Bjølgerud'); 
INSERT INTO `wp_usermeta` VALUES ('59', '4', 'nickname', 'anders'); 
INSERT INTO `wp_usermeta` VALUES ('60', '4', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('61', '4', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('62', '4', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('63', '4', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('64', '4', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('65', '4', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('66', '4', 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('67', '4', 'wp_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES ('68', '4', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media'); 
INSERT INTO `wp_usermeta` VALUES ('69', '4', 'wp_dashboard_quick_press_last_post_id', '650'); 
INSERT INTO `wp_usermeta` VALUES ('70', '4', 'wp_user-settings', 'hidetb=1&editor=tinymce&libraryContent=browse&align=none&imgsize=full&urlbutton=post'); 
INSERT INTO `wp_usermeta` VALUES ('71', '4', 'wp_user-settings-time', '1361723198'); 
INSERT INTO `wp_usermeta` VALUES ('72', '1', 'edit_pa_farge_per_page', '30'); 
INSERT INTO `wp_usermeta` VALUES ('73', '1', 'closedpostboxes_post', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('74', '1', 'metaboxhidden_post', 'a:5:{i:0;s:13:"trackbacksdiv";i:1;s:10:"postcustom";i:2;s:16:"commentstatusdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";}'); 
INSERT INTO `wp_usermeta` VALUES ('75', '4', 'edit_page_per_page', '200'); 
INSERT INTO `wp_usermeta` VALUES ('76', '4', 'closedpostboxes_product', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('77', '4', 'metaboxhidden_product', 'a:1:{i:0;s:7:"slugdiv";}'); 
INSERT INTO `wp_usermeta` VALUES ('78', '4', 'edit_product_per_page', '100'); 
INSERT INTO `wp_usermeta` VALUES ('79', '4', 'nav_menu_recently_edited', '3'); 
INSERT INTO `wp_usermeta` VALUES ('80', '4', 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'); 
INSERT INTO `wp_usermeta` VALUES ('81', '4', 'metaboxhidden_nav-menus', 'a:6:{i:0;s:8:"add-post";i:1;s:11:"add-product";i:2;s:13:"add-portfolio";i:3;s:12:"add-post_tag";i:4;s:15:"add-product_cat";i:5;s:15:"add-product_tag";}'); 
INSERT INTO `wp_usermeta` VALUES ('82', '1', 'billing_first_name', 'Solveig Maria Nes'); 
INSERT INTO `wp_usermeta` VALUES ('83', '1', 'aim', ''); 
INSERT INTO `wp_usermeta` VALUES ('84', '1', 'yim', ''); 
INSERT INTO `wp_usermeta` VALUES ('85', '1', 'jabber', ''); 
INSERT INTO `wp_usermeta` VALUES ('86', '1', 'billing_last_name', 'Solveig Maria Nes'); 
INSERT INTO `wp_usermeta` VALUES ('87', '1', 'billing_company', 'Nes Consult'); 
INSERT INTO `wp_usermeta` VALUES ('88', '1', 'billing_address_1', 'Breigata 16 G'); 
INSERT INTO `wp_usermeta` VALUES ('89', '1', 'billing_postcode', '0187'); 
INSERT INTO `wp_usermeta` VALUES ('90', '1', 'billing_city', 'Oslo'); 
INSERT INTO `wp_usermeta` VALUES ('91', '1', 'billing_country', 'NO'); 
INSERT INTO `wp_usermeta` VALUES ('92', '1', 'billing_state', 'Oslo'); 
INSERT INTO `wp_usermeta` VALUES ('93', '1', 'billing_email', 'solveigmarianes@gmail.com'); 
INSERT INTO `wp_usermeta` VALUES ('94', '1', 'billing_phone', '47878277'); 
INSERT INTO `wp_usermeta` VALUES ('97', '1', '_woocommerce_persistent_cart', 'a:1:{s:4:"cart";a:1:{s:32:"db932baf22306bf6ab9c742401a56e9e";a:8:{s:10:"product_id";i:757;s:12:"variation_id";i:761;s:9:"variation";a:2:{s:8:"pa_farge";s:4:"onyx";s:8:"pa_linse";s:5:"amber";}s:8:"quantity";i:1;s:10:"line_total";d:526.1499999999999772626324556767940521240234375;s:8:"line_tax";d:131.539999999999992041921359486877918243408203125;s:13:"line_subtotal";i:619;s:17:"line_subtotal_tax";d:154.75;}}}'); 
INSERT INTO `wp_usermeta` VALUES ('98', '1', 'meta-box-order_dashboard', 'a:4:{s:6:"normal";s:237:"dashboard_right_now,dashboard_recent_comments,dashboard_incoming_links,dashboard_plugins,dashboard_stats,woocommerce_dashboard_right_now,woocommerce_dashboard_recent_orders,woocommerce_dashboard_recent_reviews,woocommerce_dashboard_sales";s:4:"side";s:83:"dashboard_quick_press,dashboard_recent_drafts,dashboard_primary,dashboard_secondary";s:7:"column3";s:0:"";s:7:"column4";s:0:"";}'); 
INSERT INTO `wp_usermeta` VALUES ('99', '1', 'screen_layout_dashboard', '2');
# --------------------------------------------------------


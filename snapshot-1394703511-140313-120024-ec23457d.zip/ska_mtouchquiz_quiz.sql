CREATE TABLE IF NOT EXISTS `ska_mtouchquiz_quiz` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `description` mediumtext CHARACTER SET utf8 NOT NULL,
  `final_screen` mediumtext CHARACTER SET utf8 NOT NULL,
  `form_code` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `added_on` datetime NOT NULL,
  `show_hints` enum('0','1') NOT NULL DEFAULT '1',
  `show_start` enum('0','1') NOT NULL DEFAULT '1',
  `show_final` enum('0','1') NOT NULL DEFAULT '1',
  `random_questions` enum('0','1') NOT NULL DEFAULT '0',
  `random_answers` enum('0','1') NOT NULL DEFAULT '0',
  `multiple_chances` enum('0','1') NOT NULL DEFAULT '1',
  `single_page` enum('0','1') NOT NULL DEFAULT '0',
  `answer_mode` enum('0','1','2') NOT NULL DEFAULT '2',
  `time_limit` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
TRUNCATE TABLE `ska_mtouchquiz_quiz`;

# --------------------------------------------------------


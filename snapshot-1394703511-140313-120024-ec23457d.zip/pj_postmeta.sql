CREATE TABLE IF NOT EXISTS `pj_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=130 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `pj_postmeta`;
 
INSERT INTO `pj_postmeta` VALUES ('1', '2', '_wp_page_template', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('2', '5', '_edit_last', '6'); 
INSERT INTO `pj_postmeta` VALUES ('3', '5', '_edit_lock', '1394463165:4'); 
INSERT INTO `pj_postmeta` VALUES ('4', '1', '_edit_lock', '1394463109:2'); 
INSERT INTO `pj_postmeta` VALUES ('5', '12', '_edit_lock', '1394463462:4'); 
INSERT INTO `pj_postmeta` VALUES ('6', '2', '_edit_lock', '1394531918:6'); 
INSERT INTO `pj_postmeta` VALUES ('9', '15', '_wp_attached_file', '2014/03/wactsLogo-crop-e1394643209386.png'); 
INSERT INTO `pj_postmeta` VALUES ('10', '15', '_wp_attachment_metadata', 'a:5:{s:5:"width";i:156;s:6:"height";i:120;s:4:"file";s:41:"2014/03/wactsLogo-crop-e1394643209386.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"wactsLogo-crop-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `pj_postmeta` VALUES ('11', '15', '_edit_lock', '1394643212:1'); 
INSERT INTO `pj_postmeta` VALUES ('12', '15', '_wp_attachment_backup_sizes', 'a:1:{s:9:"full-orig";a:3:{s:5:"width";i:195;s:6:"height";i:150;s:4:"file";s:18:"wactsLogo-crop.png";}}'); 
INSERT INTO `pj_postmeta` VALUES ('13', '15', '_edit_last', '1'); 
INSERT INTO `pj_postmeta` VALUES ('14', '2', '_wp_trash_meta_status', 'publish'); 
INSERT INTO `pj_postmeta` VALUES ('15', '2', '_wp_trash_meta_time', '1394703297'); 
INSERT INTO `pj_postmeta` VALUES ('16', '17', '_edit_lock', '1394709092:3'); 
INSERT INTO `pj_postmeta` VALUES ('17', '18', '_edit_lock', '1394703515:3'); 
INSERT INTO `pj_postmeta` VALUES ('18', '18', '_wp_trash_meta_status', 'auto-draft'); 
INSERT INTO `pj_postmeta` VALUES ('19', '18', '_wp_trash_meta_time', '1394703515'); 
INSERT INTO `pj_postmeta` VALUES ('20', '17', '_edit_last', '3'); 
INSERT INTO `pj_postmeta` VALUES ('23', '17', '_wp_page_template', 'template_fullwidth.php'); 
INSERT INTO `pj_postmeta` VALUES ('24', '17', '_introduce_background_color', '#00afdf'); 
INSERT INTO `pj_postmeta` VALUES ('25', '17', '_introduce_text_type', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('26', '17', '_slideshow_category', '{s}'); 
INSERT INTO `pj_postmeta` VALUES ('27', '17', '_slideshow_number', '0'); 
INSERT INTO `pj_postmeta` VALUES ('28', '17', '_slideshow_type', 'nivo'); 
INSERT INTO `pj_postmeta` VALUES ('29', '17', '_layout', 'full'); 
INSERT INTO `pj_postmeta` VALUES ('30', '25', '_wp_attached_file', '2014/03/empty_profile.gif'); 
INSERT INTO `pj_postmeta` VALUES ('31', '25', '_wp_attachment_metadata', 'a:5:{s:5:"width";i:128;s:6:"height";i:128;s:4:"file";s:25:"2014/03/empty_profile.gif";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `pj_postmeta` VALUES ('32', '28', '_edit_last', '1'); 
INSERT INTO `pj_postmeta` VALUES ('33', '28', '_edit_lock', '1394711871:3'); 
INSERT INTO `pj_postmeta` VALUES ('34', '29', '_wp_attached_file', '2014/03/nithhemsedal.jpg'); 
INSERT INTO `pj_postmeta` VALUES ('35', '29', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:960;s:6:"height";i:639;s:4:"file";s:24:"2014/03/nithhemsedal.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"nithhemsedal-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"nithhemsedal-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:12:"custom_sizes";a:2:{s:7:"618x250";a:3:{s:4:"file";s:27:"29_nithhemsedal-618x250.jpg";s:5:"width";i:618;s:6:"height";s:3:"250";}s:7:"628x250";a:3:{s:4:"file";s:27:"29_nithhemsedal-628x250.jpg";s:5:"width";i:628;s:6:"height";s:3:"250";}}}'); 
INSERT INTO `pj_postmeta` VALUES ('36', '28', '_thumbnail_id', '29'); 
INSERT INTO `pj_postmeta` VALUES ('38', '28', '_introduce_text_type', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('39', '28', '_slideshow_category', '{s}'); 
INSERT INTO `pj_postmeta` VALUES ('40', '28', '_slideshow_number', '0'); 
INSERT INTO `pj_postmeta` VALUES ('41', '28', '_slideshow_type', 'nivo'); 
INSERT INTO `pj_postmeta` VALUES ('42', '28', '_layout', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('44', '32', '_edit_lock', '1394711833:3'); 
INSERT INTO `pj_postmeta` VALUES ('45', '32', '_edit_last', '3'); 
INSERT INTO `pj_postmeta` VALUES ('46', '33', '_edit_last', '2'); 
INSERT INTO `pj_postmeta` VALUES ('47', '33', '_wp_page_template', 'template_fullwidth.php'); 
INSERT INTO `pj_postmeta` VALUES ('48', '33', '_introduce_text_type', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('49', '33', '_slideshow_category', '{s}'); 
INSERT INTO `pj_postmeta` VALUES ('50', '33', '_slideshow_number', '0'); 
INSERT INTO `pj_postmeta` VALUES ('51', '33', '_slideshow_type', 'nivo'); 
INSERT INTO `pj_postmeta` VALUES ('52', '33', '_layout', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('53', '33', '_edit_lock', '1394712016:2'); 
INSERT INTO `pj_postmeta` VALUES ('54', '32', '_wp_page_template', 'template_fullwidth.php'); 
INSERT INTO `pj_postmeta` VALUES ('55', '32', '_introduce_text_type', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('56', '32', '_slideshow_category', '{s}'); 
INSERT INTO `pj_postmeta` VALUES ('57', '32', '_slideshow_number', '0'); 
INSERT INTO `pj_postmeta` VALUES ('58', '32', '_slideshow_type', 'nivo'); 
INSERT INTO `pj_postmeta` VALUES ('59', '32', '_layout', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('60', '32', '_introduce_background_color', '#95343b'); 
INSERT INTO `pj_postmeta` VALUES ('61', '47', '_edit_last', '3'); 
INSERT INTO `pj_postmeta` VALUES ('62', '47', '_edit_lock', '1394706988:3'); 
INSERT INTO `pj_postmeta` VALUES ('63', '33', '_introduce_background_color', '#0bab00'); 
INSERT INTO `pj_postmeta` VALUES ('70', '49', '_edit_lock', '1394708316:1'); 
INSERT INTO `pj_postmeta` VALUES ('65', '47', '_introduce_text_type', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('66', '47', '_slideshow_category', '{s}'); 
INSERT INTO `pj_postmeta` VALUES ('67', '47', '_slideshow_number', '0'); 
INSERT INTO `pj_postmeta` VALUES ('68', '47', '_slideshow_type', 'nivo'); 
INSERT INTO `pj_postmeta` VALUES ('69', '47', '_layout', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('71', '47', '_wp_trash_meta_status', 'publish'); 
INSERT INTO `pj_postmeta` VALUES ('72', '47', '_wp_trash_meta_time', '1394707102'); 
INSERT INTO `pj_postmeta` VALUES ('73', '57', '_edit_last', '4'); 
INSERT INTO `pj_postmeta` VALUES ('74', '57', '_edit_lock', '1394711911:4'); 
INSERT INTO `pj_postmeta` VALUES ('125', '130', '_introduce_text_type', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('126', '130', '_slideshow_category', '{s}'); 
INSERT INTO `pj_postmeta` VALUES ('127', '130', '_slideshow_number', '0'); 
INSERT INTO `pj_postmeta` VALUES ('128', '130', '_slideshow_type', 'nivo'); 
INSERT INTO `pj_postmeta` VALUES ('129', '130', '_layout', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('77', '57', '_wp_page_template', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('78', '57', '_introduce_text_type', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('79', '57', '_slideshow_category', '{s}'); 
INSERT INTO `pj_postmeta` VALUES ('80', '57', '_slideshow_number', '0'); 
INSERT INTO `pj_postmeta` VALUES ('81', '57', '_slideshow_type', 'nivo'); 
INSERT INTO `pj_postmeta` VALUES ('82', '57', '_layout', 'full'); 
INSERT INTO `pj_postmeta` VALUES ('83', '57', '_introduce_background_color', '#4c0097'); 
INSERT INTO `pj_postmeta` VALUES ('84', '72', '_edit_lock', '1394710165:4'); 
INSERT INTO `pj_postmeta` VALUES ('85', '72', '_edit_last', '4'); 
INSERT INTO `pj_postmeta` VALUES ('86', '72', '_wp_page_template', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('87', '72', '_introduce_text_type', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('88', '72', '_slideshow_category', '{s}'); 
INSERT INTO `pj_postmeta` VALUES ('89', '72', '_slideshow_number', '0'); 
INSERT INTO `pj_postmeta` VALUES ('90', '72', '_slideshow_type', 'nivo'); 
INSERT INTO `pj_postmeta` VALUES ('91', '72', '_layout', 'full'); 
INSERT INTO `pj_postmeta` VALUES ('92', '72', '_introduce_background_color', '#303030'); 
INSERT INTO `pj_postmeta` VALUES ('93', '80', '_edit_lock', '1394709833:4'); 
INSERT INTO `pj_postmeta` VALUES ('122', '130', '_edit_last', '3'); 
INSERT INTO `pj_postmeta` VALUES ('123', '130', '_edit_lock', '1394712026:3'); 
INSERT INTO `pj_postmeta` VALUES ('100', '125', '_edit_lock', '1394712025:2'); 
INSERT INTO `pj_postmeta` VALUES ('101', '125', '_edit_last', '2'); 
INSERT INTO `pj_postmeta` VALUES ('102', '125', 'incsub_event_venue', ''); 
INSERT INTO `pj_postmeta` VALUES ('103', '125', 'incsub_event_status', 'open'); 
INSERT INTO `pj_postmeta` VALUES ('104', '125', 'incsub_event_paid', ''); 
INSERT INTO `pj_postmeta` VALUES ('105', '125', 'incsub_event_fee', ''); 
INSERT INTO `pj_postmeta` VALUES ('106', '125', 'eab_event_recurring', ''); 
INSERT INTO `pj_postmeta` VALUES ('107', '125', 'eab_event_recurrence_parts', 'a:6:{s:5:"month";s:1:"1";s:3:"day";s:0:"";s:7:"weekday";s:6:"Monday";s:4:"week";s:1:"1";s:4:"time";s:0:"";s:8:"duration";s:0:"";}'); 
INSERT INTO `pj_postmeta` VALUES ('108', '125', 'eab_event_recurrence_starts', '1394668800'); 
INSERT INTO `pj_postmeta` VALUES ('109', '125', 'eab_event_recurrence_ends', '1397347200'); 
INSERT INTO `pj_postmeta` VALUES ('119', '125', 'incsub_event_no_start', '1'); 
INSERT INTO `pj_postmeta` VALUES ('120', '125', 'incsub_event_end', '2014-03-14 23:00:00'); 
INSERT INTO `pj_postmeta` VALUES ('121', '125', 'incsub_event_no_end', '0'); 
INSERT INTO `pj_postmeta` VALUES ('118', '125', 'incsub_event_start', '2014-03-14 00:01:00');
# --------------------------------------------------------


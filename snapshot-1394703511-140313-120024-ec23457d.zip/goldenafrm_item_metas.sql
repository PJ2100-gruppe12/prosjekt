CREATE TABLE IF NOT EXISTS `goldenafrm_item_metas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `meta_value` longtext,
  `field_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`),
  KEY `item_id` (`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `goldenafrm_item_metas`;
 
INSERT INTO `goldenafrm_item_metas` VALUES ('1', 'Shafi', '8', '1', '2012-04-06 22:24:10'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('2', 'shafi.adan@gmail.com', '90', '1', '2012-04-06 22:24:10'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('3', 'qisjalisjl', '12', '1', '2012-04-06 22:24:10'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('4', 'Test', '13', '1', '2012-04-06 22:24:10'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('5', 'Sama Sadeghi', '8', '2', '2012-11-10 17:12:32'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('6', 'samagoli@hotmail.com', '90', '2', '2012-11-10 17:12:32'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('7', 'Vurderer å ta privattimer og eksamensforberedelse hos dere', '12', '2', '2012-11-10 17:12:32'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('8', 'Hei, jeg skal gi en eksamen i matte dette halvåret, og en neste halvår. Jeg tar matte S1 og S2.', '13', '2', '2012-11-10 17:12:32'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('9', 'nazli rostamkhani', '8', '3', '2013-01-27 18:20:01'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('10', 'nro1976@hotmail.no', '90', '3', '2013-01-27 18:20:01'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('11', 'lære bedre norsk', '12', '3', '2013-01-27 18:20:01'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('12', 'Jeg snakke norsk men skal utvikle mitt språk.Har dere noen tilbud på nett uten lærer med noen tekster?', '13', '3', '2013-01-27 18:20:01'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('13', 'Thomas André Larssen', '8', '4', '2013-03-06 20:49:24'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('14', 'thomalars@gmail.com', '90', '4', '2013-03-06 20:49:24'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('15', 'Matte og norsk kurs eksamenforbredene', '12', '4', '2013-03-06 20:49:24'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('16', 'Hei. Jeg skal ta Eksamen som privatist i følgende fag.        MAT1005 Matematikk 2P-Y - 3PB\r\nNOR1231 Norsk hovedmål, Vg3 påbygging til generell studiekompetanse, skriftlig\r\nDato:  27 og 28 mai \r\nHvilke kurs anbefaler dere og hvilke datoer avholdes kursene?\r\n\r\nMvh\r\nThomas André Larssen', '13', '4', '2013-03-06 20:49:24'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('17', 'Shafi Adan', '8', '5', '2013-03-21 12:16:29'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('18', 'shafi.adan@gmail.com', '90', '5', '2013-03-21 12:16:29'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('19', 'Undervisning', '12', '5', '2013-03-21 12:16:29'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('20', 'Jeg ønsker privfatundervisningjsadljslajøsk¨', '13', '5', '2013-03-21 12:16:29'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('21', 'Shafi Adan', '8', '6', '2013-03-21 12:17:41'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('22', 'shafi.adan@gmail.com', '90', '6', '2013-03-21 12:17:41'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('23', 'Undervisning', '12', '6', '2013-03-21 12:17:41'); 
INSERT INTO `goldenafrm_item_metas` VALUES ('24', 'Jeg ønsker privfatundervisningjsadljslajøsk¨', '13', '6', '2013-03-21 12:17:41');
# --------------------------------------------------------


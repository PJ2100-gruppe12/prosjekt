CREATE TABLE IF NOT EXISTS `goldenafrm_display` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display_key` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `content` longtext,
  `dyncontent` longtext,
  `insert_loc` varchar(255) DEFAULT NULL,
  `param` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `show_count` varchar(255) DEFAULT NULL,
  `options` longtext,
  `form_id` int(11) DEFAULT NULL,
  `entry_id` int(11) DEFAULT NULL,
  `post_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `display_key` (`display_key`),
  KEY `form_id` (`form_id`),
  KEY `entry_id` (`entry_id`),
  KEY `post_id` (`post_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `goldenafrm_display`;

# --------------------------------------------------------


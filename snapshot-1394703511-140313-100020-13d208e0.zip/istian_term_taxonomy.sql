CREATE TABLE IF NOT EXISTS `istian_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `istian_term_taxonomy`;
 
INSERT INTO `istian_term_taxonomy` VALUES ('1', '1', 'category', '', '0', '11'); 
INSERT INTO `istian_term_taxonomy` VALUES ('2', '2', 'link_category', '', '0', '7'); 
INSERT INTO `istian_term_taxonomy` VALUES ('3', '3', 'product_type', '', '0', '1'); 
INSERT INTO `istian_term_taxonomy` VALUES ('4', '4', 'product_type', '', '0', '0'); 
INSERT INTO `istian_term_taxonomy` VALUES ('5', '5', 'product_type', '', '0', '0'); 
INSERT INTO `istian_term_taxonomy` VALUES ('6', '6', 'product_type', '', '0', '0'); 
INSERT INTO `istian_term_taxonomy` VALUES ('7', '7', 'shop_order_status', '', '0', '0'); 
INSERT INTO `istian_term_taxonomy` VALUES ('8', '8', 'shop_order_status', '', '0', '0'); 
INSERT INTO `istian_term_taxonomy` VALUES ('9', '9', 'shop_order_status', '', '0', '0'); 
INSERT INTO `istian_term_taxonomy` VALUES ('10', '10', 'shop_order_status', '', '0', '0'); 
INSERT INTO `istian_term_taxonomy` VALUES ('11', '11', 'shop_order_status', '', '0', '0'); 
INSERT INTO `istian_term_taxonomy` VALUES ('12', '12', 'shop_order_status', '', '0', '0'); 
INSERT INTO `istian_term_taxonomy` VALUES ('13', '13', 'shop_order_status', '', '0', '0'); 
INSERT INTO `istian_term_taxonomy` VALUES ('14', '14', 'wpsc_product_category', '', '0', '1');
# --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `goldenausermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `goldenausermeta`;
 
INSERT INTO `goldenausermeta` VALUES ('1', '1', 'first_name', ''); 
INSERT INTO `goldenausermeta` VALUES ('2', '1', 'last_name', ''); 
INSERT INTO `goldenausermeta` VALUES ('3', '1', 'nickname', 'admin'); 
INSERT INTO `goldenausermeta` VALUES ('4', '1', 'description', ''); 
INSERT INTO `goldenausermeta` VALUES ('5', '1', 'rich_editing', 'true'); 
INSERT INTO `goldenausermeta` VALUES ('6', '1', 'comment_shortcuts', 'false'); 
INSERT INTO `goldenausermeta` VALUES ('7', '1', 'admin_color', 'fresh'); 
INSERT INTO `goldenausermeta` VALUES ('8', '1', 'use_ssl', '0'); 
INSERT INTO `goldenausermeta` VALUES ('9', '1', 'show_admin_bar_front', 'true'); 
INSERT INTO `goldenausermeta` VALUES ('10', '1', 'goldenacapabilities', 'a:5:{s:13:"administrator";s:1:"1";s:14:"frm_view_forms";s:1:"1";s:14:"frm_edit_forms";s:1:"1";s:16:"frm_delete_forms";s:1:"1";s:19:"frm_change_settings";s:1:"1";}'); 
INSERT INTO `goldenausermeta` VALUES ('11', '1', 'goldenauser_level', '10'); 
INSERT INTO `goldenausermeta` VALUES ('12', '1', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_customize_current_theme_link,wp350_media'); 
INSERT INTO `goldenausermeta` VALUES ('13', '1', 'show_welcome_panel', '1'); 
INSERT INTO `goldenausermeta` VALUES ('14', '1', 'goldenadashboard_quick_press_last_post_id', '3'); 
INSERT INTO `goldenausermeta` VALUES ('15', '1', 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'); 
INSERT INTO `goldenausermeta` VALUES ('16', '1', 'metaboxhidden_nav-menus', 'a:2:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";}'); 
INSERT INTO `goldenausermeta` VALUES ('17', '1', 'goldenauser-settings', 'hidetb=1&align=left&editor=tinymce&imgsize=full&wplink=1&libraryContent=browse'); 
INSERT INTO `goldenausermeta` VALUES ('18', '1', 'goldenauser-settings-time', '1363948872'); 
INSERT INTO `goldenausermeta` VALUES ('19', '1', 'nav_menu_recently_edited', '3'); 
INSERT INTO `goldenausermeta` VALUES ('20', '1', 'closedpostboxes_post', 'a:0:{}'); 
INSERT INTO `goldenausermeta` VALUES ('21', '1', 'metaboxhidden_post', 'a:5:{i:0;s:13:"trackbacksdiv";i:1;s:10:"postcustom";i:2;s:16:"commentstatusdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";}'); 
INSERT INTO `goldenausermeta` VALUES ('22', '1', 'closedpostboxes_page', 'a:0:{}'); 
INSERT INTO `goldenausermeta` VALUES ('23', '1', 'metaboxhidden_page', 'a:4:{i:0;s:10:"postcustom";i:1;s:16:"commentstatusdiv";i:2;s:7:"slugdiv";i:3;s:9:"authordiv";}'); 
INSERT INTO `goldenausermeta` VALUES ('24', '2', 'first_name', 'Celine'); 
INSERT INTO `goldenausermeta` VALUES ('25', '2', 'last_name', 'Farestveit'); 
INSERT INTO `goldenausermeta` VALUES ('26', '2', 'nickname', 'celine'); 
INSERT INTO `goldenausermeta` VALUES ('27', '2', 'description', ''); 
INSERT INTO `goldenausermeta` VALUES ('28', '2', 'rich_editing', 'true'); 
INSERT INTO `goldenausermeta` VALUES ('29', '2', 'comment_shortcuts', 'false'); 
INSERT INTO `goldenausermeta` VALUES ('30', '2', 'admin_color', 'fresh'); 
INSERT INTO `goldenausermeta` VALUES ('31', '2', 'use_ssl', '0'); 
INSERT INTO `goldenausermeta` VALUES ('32', '2', 'show_admin_bar_front', 'true'); 
INSERT INTO `goldenausermeta` VALUES ('33', '2', 'goldenacapabilities', 'a:1:{s:13:"administrator";s:1:"1";}'); 
INSERT INTO `goldenausermeta` VALUES ('34', '2', 'goldenauser_level', '10'); 
INSERT INTO `goldenausermeta` VALUES ('35', '2', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets'); 
INSERT INTO `goldenausermeta` VALUES ('36', '3', 'first_name', ''); 
INSERT INTO `goldenausermeta` VALUES ('37', '3', 'last_name', ''); 
INSERT INTO `goldenausermeta` VALUES ('38', '3', 'nickname', 'seo-rune'); 
INSERT INTO `goldenausermeta` VALUES ('39', '3', 'description', ''); 
INSERT INTO `goldenausermeta` VALUES ('40', '3', 'rich_editing', 'true'); 
INSERT INTO `goldenausermeta` VALUES ('41', '3', 'comment_shortcuts', 'false'); 
INSERT INTO `goldenausermeta` VALUES ('42', '3', 'admin_color', 'fresh'); 
INSERT INTO `goldenausermeta` VALUES ('43', '3', 'use_ssl', '0'); 
INSERT INTO `goldenausermeta` VALUES ('44', '3', 'show_admin_bar_front', 'true'); 
INSERT INTO `goldenausermeta` VALUES ('45', '3', 'goldenacapabilities', 'a:1:{s:10:"subscriber";s:1:"1";}'); 
INSERT INTO `goldenausermeta` VALUES ('46', '3', 'goldenauser_level', '0'); 
INSERT INTO `goldenausermeta` VALUES ('47', '3', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets'); 
INSERT INTO `goldenausermeta` VALUES ('48', '1', 'edit_page_per_page', '22');
# --------------------------------------------------------


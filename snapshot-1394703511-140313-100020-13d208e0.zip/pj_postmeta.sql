CREATE TABLE IF NOT EXISTS `pj_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `pj_postmeta`;
 
INSERT INTO `pj_postmeta` VALUES ('1', '2', '_wp_page_template', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('2', '5', '_edit_last', '6'); 
INSERT INTO `pj_postmeta` VALUES ('3', '5', '_edit_lock', '1394463165:4'); 
INSERT INTO `pj_postmeta` VALUES ('4', '1', '_edit_lock', '1394463109:2'); 
INSERT INTO `pj_postmeta` VALUES ('5', '12', '_edit_lock', '1394463462:4'); 
INSERT INTO `pj_postmeta` VALUES ('6', '2', '_edit_lock', '1394531918:6'); 
INSERT INTO `pj_postmeta` VALUES ('9', '15', '_wp_attached_file', '2014/03/wactsLogo-crop-e1394643209386.png'); 
INSERT INTO `pj_postmeta` VALUES ('10', '15', '_wp_attachment_metadata', 'a:5:{s:5:"width";i:156;s:6:"height";i:120;s:4:"file";s:41:"2014/03/wactsLogo-crop-e1394643209386.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"wactsLogo-crop-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `pj_postmeta` VALUES ('11', '15', '_edit_lock', '1394643212:1'); 
INSERT INTO `pj_postmeta` VALUES ('12', '15', '_wp_attachment_backup_sizes', 'a:1:{s:9:"full-orig";a:3:{s:5:"width";i:195;s:6:"height";i:150;s:4:"file";s:18:"wactsLogo-crop.png";}}'); 
INSERT INTO `pj_postmeta` VALUES ('13', '15', '_edit_last', '1'); 
INSERT INTO `pj_postmeta` VALUES ('14', '2', '_wp_trash_meta_status', 'publish'); 
INSERT INTO `pj_postmeta` VALUES ('15', '2', '_wp_trash_meta_time', '1394703297'); 
INSERT INTO `pj_postmeta` VALUES ('16', '17', '_edit_lock', '1394704822:1'); 
INSERT INTO `pj_postmeta` VALUES ('17', '18', '_edit_lock', '1394703515:3'); 
INSERT INTO `pj_postmeta` VALUES ('18', '18', '_wp_trash_meta_status', 'auto-draft'); 
INSERT INTO `pj_postmeta` VALUES ('19', '18', '_wp_trash_meta_time', '1394703515'); 
INSERT INTO `pj_postmeta` VALUES ('20', '17', '_edit_last', '1'); 
INSERT INTO `pj_postmeta` VALUES ('23', '17', '_wp_page_template', 'template_fullwidth.php'); 
INSERT INTO `pj_postmeta` VALUES ('24', '17', '_introduce_background_color', '#0000FF'); 
INSERT INTO `pj_postmeta` VALUES ('25', '17', '_introduce_text_type', 'default'); 
INSERT INTO `pj_postmeta` VALUES ('26', '17', '_slideshow_category', '{s}'); 
INSERT INTO `pj_postmeta` VALUES ('27', '17', '_slideshow_number', '0'); 
INSERT INTO `pj_postmeta` VALUES ('28', '17', '_slideshow_type', 'nivo'); 
INSERT INTO `pj_postmeta` VALUES ('29', '17', '_layout', 'full');
# --------------------------------------------------------


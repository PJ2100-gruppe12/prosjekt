CREATE TABLE IF NOT EXISTS `nesconsultkingsize_albums` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `a_order` smallint(5) unsigned NOT NULL,
  `main_photo` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `nesconsultkingsize_albums`;
 
INSERT INTO `nesconsultkingsize_albums` VALUES ('1', 'background', 'background image slider', '0', '0');
# --------------------------------------------------------


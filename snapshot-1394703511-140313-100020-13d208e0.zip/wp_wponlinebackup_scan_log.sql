CREATE TABLE IF NOT EXISTS `wp_wponlinebackup_scan_log` (
  `scan_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL,
  `type` smallint(1) unsigned NOT NULL,
  `name` varbinary(255) NOT NULL,
  PRIMARY KEY (`scan_id`),
  UNIQUE KEY `name` (`parent_id`,`type`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_wponlinebackup_scan_log`;

# --------------------------------------------------------


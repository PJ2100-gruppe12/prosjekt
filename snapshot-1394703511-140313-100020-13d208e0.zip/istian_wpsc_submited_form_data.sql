CREATE TABLE IF NOT EXISTS `istian_wpsc_submited_form_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `form_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `log_id` (`log_id`,`form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `istian_wpsc_submited_form_data`;

# --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `pj_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `pj_posts`;
 
INSERT INTO `pj_posts` VALUES ('1', '1', '2014-03-10 14:47:05', '2014-03-10 14:47:05', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-03-10 14:47:05', '2014-03-10 14:47:05', '', '0', 'http://pj2100.nesconsult.no/?p=1', '0', 'post', '', '0'); 
INSERT INTO `pj_posts` VALUES ('2', '1', '2014-03-10 14:47:05', '2014-03-10 14:47:05', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://pj2100.nesconsult.no/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'open', 'open', '', 'sample-page', '', '', '2014-03-13 09:34:57', '2014-03-13 09:34:57', '', '0', 'http://pj2100.nesconsult.no/?page_id=2', '0', 'page', '', '0'); 
INSERT INTO `pj_posts` VALUES ('3', '1', '2014-03-10 14:47:24', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-03-10 14:47:24', '0000-00-00 00:00:00', '', '0', 'http://pj2100.nesconsult.no/?p=3', '0', 'post', '', '0'); 
INSERT INTO `pj_posts` VALUES ('4', '3', '2014-03-10 14:49:24', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-03-10 14:49:24', '0000-00-00 00:00:00', '', '0', 'http://pj2100.nesconsult.no/?p=4', '0', 'post', '', '0'); 
INSERT INTO `pj_posts` VALUES ('5', '6', '2014-03-10 14:51:12', '0000-00-00 00:00:00', 'Thiz iz cool.', 'Cool', '', 'draft', 'open', 'open', '', '', '', '', '2014-03-10 14:51:12', '2014-03-10 14:51:12', '', '0', 'http://pj2100.nesconsult.no/?p=5', '0', 'post', '', '0'); 
INSERT INTO `pj_posts` VALUES ('6', '4', '2014-03-10 14:50:54', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-03-10 14:50:54', '0000-00-00 00:00:00', '', '0', 'http://pj2100.nesconsult.no/?p=6', '0', 'post', '', '0'); 
INSERT INTO `pj_posts` VALUES ('7', '6', '2014-03-10 14:51:12', '2014-03-10 14:51:12', 'Thiz iz cool.', 'Cool', '', 'inherit', 'open', 'open', '', '5-revision-v1', '', '', '2014-03-10 14:51:12', '2014-03-10 14:51:12', '', '5', 'http://pj2100.nesconsult.no/?p=7', '0', 'revision', '', '0'); 
INSERT INTO `pj_posts` VALUES ('8', '6', '2014-03-10 14:51:12', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-03-10 14:51:12', '0000-00-00 00:00:00', '', '0', 'http://pj2100.nesconsult.no/?p=8', '0', 'post', '', '0'); 
INSERT INTO `pj_posts` VALUES ('9', '5', '2014-03-10 14:51:55', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-03-10 14:51:55', '0000-00-00 00:00:00', '', '0', 'http://pj2100.nesconsult.no/?p=9', '0', 'post', '', '0'); 
INSERT INTO `pj_posts` VALUES ('10', '2', '2014-03-10 14:51:58', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-03-10 14:51:58', '0000-00-00 00:00:00', '', '0', 'http://pj2100.nesconsult.no/?p=10', '0', 'post', '', '0'); 
INSERT INTO `pj_posts` VALUES ('11', '4', '2014-03-10 14:57:23', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-03-10 14:57:23', '0000-00-00 00:00:00', '', '0', 'http://pj2100.nesconsult.no/?p=11', '0', 'post', '', '0'); 
INSERT INTO `pj_posts` VALUES ('12', '4', '2014-03-10 14:57:25', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-03-10 14:57:25', '0000-00-00 00:00:00', '', '0', 'http://pj2100.nesconsult.no/?p=12', '0', 'post', '', '0'); 
INSERT INTO `pj_posts` VALUES ('13', '2', '2014-03-11 09:54:03', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-03-11 09:54:03', '0000-00-00 00:00:00', '', '0', 'http://pj2100.nesconsult.no/?page_id=13', '0', 'page', '', '0'); 
INSERT INTO `pj_posts` VALUES ('15', '1', '2014-03-12 16:48:22', '2014-03-12 16:48:22', '', 'wactsLogo-crop', '', 'inherit', 'open', 'open', '', 'wactslogo-crop', '', '', '2014-03-12 16:48:22', '2014-03-12 16:48:22', '', '0', 'http://pj2100.nesconsult.no/wp-content/uploads/2014/03/wactsLogo-crop.png', '0', 'attachment', 'image/png', '0'); 
INSERT INTO `pj_posts` VALUES ('16', '2', '2014-03-13 09:34:57', '2014-03-13 09:34:57', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://pj2100.nesconsult.no/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2014-03-13 09:34:57', '2014-03-13 09:34:57', '', '2', 'http://pj2100.nesconsult.no/2-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `pj_posts` VALUES ('17', '2', '2014-03-13 09:39:55', '2014-03-13 09:39:55', '[one_half]\r\n\r\nInfoboks med linker\r\n\r\nOm idrettsutvalget\r\n\r\n[/one_half] [one_half_last]\r\n\r\n&nbsp;\r\n\r\nEventkalender\r\n\r\n[/one_half_last]\r\n\r\n[two_third]\r\n\r\nSiste nyheter fra idrettsutvalget\r\n\r\n[/two_third] [one_third_last]\r\n\r\nStyret\r\n\r\n[/one_third_last]', 'Idrettsutvalget', '', 'publish', 'open', 'open', '', 'idrettsutvalget', '', '', '2014-03-13 10:00:21', '2014-03-13 10:00:21', '', '0', 'http://pj2100.nesconsult.no/?page_id=17', '0', 'page', '', '0'); 
INSERT INTO `pj_posts` VALUES ('18', '3', '2014-03-13 09:37:33', '2014-03-13 09:37:33', '', 'Auto Draft', '', 'trash', 'open', 'open', '', 'auto-draft', '', '', '2014-03-13 09:38:35', '2014-03-13 09:38:35', '', '0', 'http://pj2100.nesconsult.no/?page_id=18', '0', 'page', '', '0'); 
INSERT INTO `pj_posts` VALUES ('19', '3', '2014-03-13 09:38:35', '2014-03-13 09:38:35', '', 'Auto Draft', '', 'inherit', 'open', 'open', '', '18-revision-v1', '', '', '2014-03-13 09:38:35', '2014-03-13 09:38:35', '', '18', 'http://pj2100.nesconsult.no/18-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `pj_posts` VALUES ('20', '2', '2014-03-13 09:41:45', '2014-03-13 09:41:45', '', 'Idrettsutvalget', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-03-13 09:41:45', '2014-03-13 09:41:45', '', '17', 'http://pj2100.nesconsult.no/17-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `pj_posts` VALUES ('21', '1', '2014-03-13 09:59:49', '2014-03-13 09:59:49', '[one_half]\n\nInfoboks med linker\n\nOm id\n\n[/one_half] [one_half_last]\n\n&nbsp;\n\nEventkalender\n\n[/one_half_last]\n\n[two_third] [/two_third] [one_third_last] [/one_third_last]', 'Idrettsutvalget', '', 'inherit', 'open', 'open', '', '17-autosave-v1', '', '', '2014-03-13 09:59:49', '2014-03-13 09:59:49', '', '17', 'http://pj2100.nesconsult.no/17-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `pj_posts` VALUES ('22', '1', '2014-03-13 10:00:21', '2014-03-13 10:00:21', '[one_half]\r\n\r\nInfoboks med linker\r\n\r\nOm idrettsutvalget\r\n\r\n[/one_half] [one_half_last]\r\n\r\n&nbsp;\r\n\r\nEventkalender\r\n\r\n[/one_half_last]\r\n\r\n[two_third]\r\n\r\nSiste nyheter fra idrettsutvalget\r\n\r\n[/two_third] [one_third_last]\r\n\r\nStyret\r\n\r\n[/one_third_last]', 'Idrettsutvalget', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-03-13 10:00:21', '2014-03-13 10:00:21', '', '17', 'http://pj2100.nesconsult.no/17-revision-v1/', '0', 'revision', '', '0');
# --------------------------------------------------------


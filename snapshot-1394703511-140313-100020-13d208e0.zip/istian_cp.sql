CREATE TABLE IF NOT EXISTS `istian_cp` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `type` varchar(256) NOT NULL,
  `data` text NOT NULL,
  `points` bigint(20) NOT NULL,
  `timestamp` bigint(20) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `istian_cp`;
 
INSERT INTO `istian_cp` VALUES ('1', '1', 'post', '36', '20', '1366975923'); 
INSERT INTO `istian_cp` VALUES ('2', '1', 'post', '37', '20', '1366975923'); 
INSERT INTO `istian_cp` VALUES ('3', '1', 'post', '38', '20', '1366975923'); 
INSERT INTO `istian_cp` VALUES ('4', '1', 'post', '39', '20', '1366975923'); 
INSERT INTO `istian_cp` VALUES ('5', '1', 'post', '40', '20', '1366975923'); 
INSERT INTO `istian_cp` VALUES ('6', '1', 'post', '41', '20', '1366975944'); 
INSERT INTO `istian_cp` VALUES ('7', '1', 'post', '42', '20', '1366975944'); 
INSERT INTO `istian_cp` VALUES ('8', '1', 'post', '43', '20', '1366975944'); 
INSERT INTO `istian_cp` VALUES ('9', '1', 'post', '44', '20', '1366975944'); 
INSERT INTO `istian_cp` VALUES ('10', '1', 'post', '45', '20', '1366975944');
# --------------------------------------------------------


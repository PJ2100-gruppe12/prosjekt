CREATE TABLE IF NOT EXISTS `nesconsultlinks` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `nesconsultlinks`;
 
INSERT INTO `nesconsultlinks` VALUES ('1', 'http://codex.wordpress.org/', 'Documentation', '', '', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', ''); 
INSERT INTO `nesconsultlinks` VALUES ('2', 'http://wordpress.org/news/', 'WordPress Blog', '', '', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', 'http://wordpress.org/news/feed/'); 
INSERT INTO `nesconsultlinks` VALUES ('3', 'http://wordpress.org/extend/ideas/', 'Suggest Ideas', '', '', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', ''); 
INSERT INTO `nesconsultlinks` VALUES ('4', 'http://wordpress.org/support/', 'Support Forum', '', '', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', ''); 
INSERT INTO `nesconsultlinks` VALUES ('5', 'http://wordpress.org/extend/plugins/', 'Plugins', '', '', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', ''); 
INSERT INTO `nesconsultlinks` VALUES ('6', 'http://wordpress.org/extend/themes/', 'Themes', '', '', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', ''); 
INSERT INTO `nesconsultlinks` VALUES ('7', 'http://planet.wordpress.org/', 'WordPress Planet', '', '', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', ''); 
INSERT INTO `nesconsultlinks` VALUES ('8', 'http://www.goldenacademy.no', 'Golden Academy', '', '_blank', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', ''); 
INSERT INTO `nesconsultlinks` VALUES ('9', 'http://www.bibb.no', 'BI-Studentenes Bemanningsbyrå', '', '_blank', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', ''); 
INSERT INTO `nesconsultlinks` VALUES ('10', 'http://www.hardanger-resort.com', 'Hardanger Feriesenter', '', '_blank', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', ''); 
INSERT INTO `nesconsultlinks` VALUES ('11', 'http://www.farestveit-consulting.no', 'Farestveit Consulting', '', '_blank', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', ''); 
INSERT INTO `nesconsultlinks` VALUES ('12', 'http://www.sfhv.no', 'Senter for helse og velvære', '', '_blank', '', 'Y', '1', '0', '0000-00-00 00:00:00', '', '', '');
# --------------------------------------------------------


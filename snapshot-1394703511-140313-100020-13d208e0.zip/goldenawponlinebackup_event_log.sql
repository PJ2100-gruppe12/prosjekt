CREATE TABLE IF NOT EXISTS `goldenawponlinebackup_event_log` (
  `event_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `activity_id` int(10) unsigned NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `event` text NOT NULL,
  PRIMARY KEY (`event_id`),
  KEY `activity_id` (`activity_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `goldenawponlinebackup_event_log`;
 
INSERT INTO `goldenawponlinebackup_event_log` VALUES ('1', '1', '1363871219', '0', 'Backup starting...'); 
INSERT INTO `goldenawponlinebackup_event_log` VALUES ('2', '1', '1363871220', '0', 'Initialisation completed.'); 
INSERT INTO `goldenawponlinebackup_event_log` VALUES ('3', '1', '1363871223', '0', 'Database backup completed.'); 
INSERT INTO `goldenawponlinebackup_event_log` VALUES ('4', '1', '1363871233', '0', 'Folder /goldenacademy/wp-content/plugins/wponlinebackup/tmp was excluded: Online Backup for WordPress temporary backup directory'); 
INSERT INTO `goldenawponlinebackup_event_log` VALUES ('5', '1', '1363871258', '0', 'File system backup completed.'); 
INSERT INTO `goldenawponlinebackup_event_log` VALUES ('6', '1', '1363871258', '0', 'Backup complete.'); 
INSERT INTO `goldenawponlinebackup_event_log` VALUES ('7', '2', '1363950368', '0', 'Backup starting...'); 
INSERT INTO `goldenawponlinebackup_event_log` VALUES ('8', '2', '1363950369', '0', 'Initialisation completed.'); 
INSERT INTO `goldenawponlinebackup_event_log` VALUES ('9', '2', '1363950371', '0', 'Database backup completed.'); 
INSERT INTO `goldenawponlinebackup_event_log` VALUES ('10', '2', '1363950379', '0', 'Folder /goldenacademy/wp-content/plugins/wponlinebackup/tmp was excluded: Online Backup for WordPress temporary backup directory'); 
INSERT INTO `goldenawponlinebackup_event_log` VALUES ('11', '2', '1363950421', '0', 'File system backup completed.'); 
INSERT INTO `goldenawponlinebackup_event_log` VALUES ('12', '2', '1363950421', '0', 'Backup complete.');
# --------------------------------------------------------


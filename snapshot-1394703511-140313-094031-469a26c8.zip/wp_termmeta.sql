CREATE TABLE IF NOT EXISTS `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_termmeta`;
 
INSERT INTO `wp_termmeta` VALUES ('1', '36', '_rtl', '0'); 
INSERT INTO `wp_termmeta` VALUES ('2', '37', '_rtl', '0'); 
INSERT INTO `wp_termmeta` VALUES ('3', '1', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('4', '39', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('5', '40', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('6', '41', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('7', '42', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('8', '43', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('9', '44', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('10', '45', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('11', '46', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('12', '47', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('13', '32', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('14', '31', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('15', '30', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('16', '29', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('17', '28', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('18', '27', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('19', '26', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('20', '25', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('21', '24', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('22', '23', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('23', '22', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('25', '48', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('26', '48', '_translations', 'a:2:{s:2:"en";i:48;s:2:"nb";i:41;}'); 
INSERT INTO `wp_termmeta` VALUES ('27', '41', '_translations', 'a:2:{s:2:"en";i:48;s:2:"nb";i:41;}'); 
INSERT INTO `wp_termmeta` VALUES ('28', '47', '_translations', 'a:2:{s:2:"en";i:47;s:2:"nb";i:24;}'); 
INSERT INTO `wp_termmeta` VALUES ('29', '24', '_translations', 'a:2:{s:2:"en";i:47;s:2:"nb";i:24;}'); 
INSERT INTO `wp_termmeta` VALUES ('30', '46', '_translations', 'a:2:{s:2:"en";i:46;s:2:"nb";i:25;}'); 
INSERT INTO `wp_termmeta` VALUES ('31', '25', '_translations', 'a:2:{s:2:"en";i:46;s:2:"nb";i:25;}'); 
INSERT INTO `wp_termmeta` VALUES ('32', '45', '_translations', 'a:2:{s:2:"en";i:45;s:2:"nb";i:42;}'); 
INSERT INTO `wp_termmeta` VALUES ('34', '42', '_translations', 'a:2:{s:2:"en";i:45;s:2:"nb";i:42;}'); 
INSERT INTO `wp_termmeta` VALUES ('35', '49', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('36', '49', '_translations', 'a:2:{s:2:"en";i:49;s:2:"nb";i:40;}'); 
INSERT INTO `wp_termmeta` VALUES ('37', '40', '_translations', 'a:2:{s:2:"en";i:49;s:2:"nb";i:40;}'); 
INSERT INTO `wp_termmeta` VALUES ('38', '50', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('39', '50', '_translations', 'a:2:{s:2:"en";i:50;s:2:"nb";i:32;}'); 
INSERT INTO `wp_termmeta` VALUES ('40', '32', '_translations', 'a:2:{s:2:"en";i:50;s:2:"nb";i:32;}'); 
INSERT INTO `wp_termmeta` VALUES ('41', '51', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('42', '51', '_translations', 'a:2:{s:2:"en";i:51;s:2:"nb";i:31;}'); 
INSERT INTO `wp_termmeta` VALUES ('43', '31', '_translations', 'a:2:{s:2:"en";i:51;s:2:"nb";i:31;}'); 
INSERT INTO `wp_termmeta` VALUES ('44', '52', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('45', '52', '_translations', 'a:2:{s:2:"en";i:52;s:2:"nb";i:30;}'); 
INSERT INTO `wp_termmeta` VALUES ('46', '30', '_translations', 'a:2:{s:2:"en";i:52;s:2:"nb";i:30;}'); 
INSERT INTO `wp_termmeta` VALUES ('47', '53', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('48', '53', '_translations', 'a:2:{s:2:"en";i:53;s:2:"nb";i:29;}'); 
INSERT INTO `wp_termmeta` VALUES ('49', '29', '_translations', 'a:2:{s:2:"en";i:53;s:2:"nb";i:29;}'); 
INSERT INTO `wp_termmeta` VALUES ('50', '54', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('51', '54', '_translations', 'a:2:{s:2:"en";i:54;s:2:"nb";i:28;}'); 
INSERT INTO `wp_termmeta` VALUES ('52', '28', '_translations', 'a:2:{s:2:"en";i:54;s:2:"nb";i:28;}'); 
INSERT INTO `wp_termmeta` VALUES ('53', '55', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('54', '55', '_translations', 'a:2:{s:2:"en";i:55;s:2:"nb";i:27;}'); 
INSERT INTO `wp_termmeta` VALUES ('55', '27', '_translations', 'a:2:{s:2:"en";i:55;s:2:"nb";i:27;}'); 
INSERT INTO `wp_termmeta` VALUES ('56', '56', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('57', '56', '_translations', 'a:2:{s:2:"en";i:56;s:2:"nb";i:26;}'); 
INSERT INTO `wp_termmeta` VALUES ('58', '26', '_translations', 'a:2:{s:2:"en";i:56;s:2:"nb";i:26;}'); 
INSERT INTO `wp_termmeta` VALUES ('59', '57', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('60', '57', '_translations', 'a:2:{s:2:"en";i:57;s:2:"nb";i:23;}'); 
INSERT INTO `wp_termmeta` VALUES ('61', '23', '_translations', 'a:2:{s:2:"en";i:57;s:2:"nb";i:23;}'); 
INSERT INTO `wp_termmeta` VALUES ('62', '58', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('63', '58', '_translations', 'a:2:{s:2:"en";i:58;s:2:"nb";i:22;}'); 
INSERT INTO `wp_termmeta` VALUES ('64', '22', '_translations', 'a:2:{s:2:"en";i:58;s:2:"nb";i:22;}'); 
INSERT INTO `wp_termmeta` VALUES ('65', '59', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('66', '34', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('67', '33', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('68', '44', '_translations', 'a:2:{s:2:"en";i:44;s:2:"nb";i:34;}'); 
INSERT INTO `wp_termmeta` VALUES ('69', '34', '_translations', 'a:2:{s:2:"en";i:44;s:2:"nb";i:34;}'); 
INSERT INTO `wp_termmeta` VALUES ('70', '43', '_translations', 'a:2:{s:2:"en";i:43;s:2:"nb";i:33;}'); 
INSERT INTO `wp_termmeta` VALUES ('71', '33', '_translations', 'a:2:{s:2:"en";i:43;s:2:"nb";i:33;}'); 
INSERT INTO `wp_termmeta` VALUES ('72', '60', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('73', '61', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('74', '61', '_translations', 'a:2:{s:2:"en";i:61;s:2:"nb";i:60;}'); 
INSERT INTO `wp_termmeta` VALUES ('75', '60', '_translations', 'a:2:{s:2:"en";i:61;s:2:"nb";i:60;}'); 
INSERT INTO `wp_termmeta` VALUES ('76', '8', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('77', '7', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('78', '62', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('79', '62', '_translations', 'a:2:{s:2:"en";i:62;s:2:"nb";i:8;}'); 
INSERT INTO `wp_termmeta` VALUES ('80', '8', '_translations', 'a:2:{s:2:"en";i:62;s:2:"nb";i:8;}'); 
INSERT INTO `wp_termmeta` VALUES ('81', '63', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('82', '63', '_translations', 'a:2:{s:2:"en";i:63;s:2:"nb";i:7;}'); 
INSERT INTO `wp_termmeta` VALUES ('83', '7', '_translations', 'a:2:{s:2:"en";i:63;s:2:"nb";i:7;}'); 
INSERT INTO `wp_termmeta` VALUES ('84', '64', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('85', '65', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('86', '65', '_translations', 'a:2:{s:2:"en";i:65;s:2:"nb";i:64;}'); 
INSERT INTO `wp_termmeta` VALUES ('87', '64', '_translations', 'a:2:{s:2:"en";i:65;s:2:"nb";i:64;}'); 
INSERT INTO `wp_termmeta` VALUES ('88', '66', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('89', '67', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('90', '67', '_translations', 'a:1:{s:2:"en";i:67;}'); 
INSERT INTO `wp_termmeta` VALUES ('91', '66', '_translations', 'a:2:{s:2:"en";i:67;s:2:"nb";i:66;}'); 
INSERT INTO `wp_termmeta` VALUES ('94', '69', '_language', '36'); 
INSERT INTO `wp_termmeta` VALUES ('95', '69', '_translations', 'a:2:{s:2:"en";i:70;s:2:"nb";i:69;}'); 
INSERT INTO `wp_termmeta` VALUES ('96', '70', '_language', '37'); 
INSERT INTO `wp_termmeta` VALUES ('97', '70', '_translations', 'a:2:{s:2:"en";i:70;s:2:"nb";i:69;}');
# --------------------------------------------------------


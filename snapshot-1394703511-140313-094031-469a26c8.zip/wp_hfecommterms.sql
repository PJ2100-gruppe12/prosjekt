CREATE TABLE IF NOT EXISTS `wp_hfecommterms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_hfecommterms`;
 
INSERT INTO `wp_hfecommterms` VALUES ('1', 'Uncategorized', 'uncategorized', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('2', 'Blogroll', 'blogroll', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('3', 'Opplevelser', 'opplevelser', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('4', 'Servering', 'servering', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('5', 'Innkvartering', 'innkvartering', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('6', 'Transport', 'transport', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('7', 'natur', 'natur', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('8', 'kulturhistorie', 'kulturhistorie', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('9', 'simple', 'simple', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('10', 'grouped', 'grouped', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('11', 'variable', 'variable', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('12', 'external', 'external', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('13', 'pending', 'pending', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('14', 'failed', 'failed', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('15', 'on-hold', 'on-hold', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('16', 'processing', 'processing', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('17', 'completed', 'completed', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('18', 'refunded', 'refunded', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('19', 'cancelled', 'cancelled', '0'); 
INSERT INTO `wp_hfecommterms` VALUES ('20', 'Shop menu', 'shop-menu', '0');
# --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `wp_wponlinebackup_items` (
  `bin` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL,
  `type` smallint(1) unsigned NOT NULL,
  `name` varbinary(255) NOT NULL,
  `name_bin` varbinary(255) NOT NULL,
  `exists` smallint(1) unsigned DEFAULT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  `mod_time` int(10) unsigned DEFAULT NULL,
  `backup` smallint(1) unsigned DEFAULT NULL,
  `new_exists` smallint(1) unsigned DEFAULT NULL,
  `new_file_size` int(10) unsigned DEFAULT NULL,
  `new_mod_time` int(10) unsigned DEFAULT NULL,
  `activity_id` int(10) unsigned NOT NULL,
  `counter` int(10) unsigned NOT NULL,
  `path` blob NOT NULL,
  PRIMARY KEY (`bin`,`item_id`),
  UNIQUE KEY `item` (`bin`,`parent_id`,`type`,`name`),
  KEY `browse` (`bin`,`parent_id`,`exists`,`type`,`name`),
  KEY `activity_id` (`activity_id`,`backup`,`bin`,`item_id`),
  KEY `exists` (`bin`,`exists`,`activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_wponlinebackup_items`;

# --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `goldenawponlinebackup_scan_log` (
  `scan_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL,
  `type` smallint(1) unsigned NOT NULL,
  `name` varbinary(255) NOT NULL,
  PRIMARY KEY (`scan_id`),
  UNIQUE KEY `name` (`parent_id`,`type`,`name`)
) ENGINE=MyISAM AUTO_INCREMENT=468 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `goldenawponlinebackup_scan_log`;

# --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `ska_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `ska_terms`;
 
INSERT INTO `ska_terms` VALUES ('1', 'Uncategorized', 'uncategorized', '0'); 
INSERT INTO `ska_terms` VALUES ('2', 'Blogroll', 'blogroll', '0');
# --------------------------------------------------------


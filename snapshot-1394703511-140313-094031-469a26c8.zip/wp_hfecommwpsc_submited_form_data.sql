CREATE TABLE IF NOT EXISTS `wp_hfecommwpsc_submited_form_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `form_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `log_id` (`log_id`,`form_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_hfecommwpsc_submited_form_data`;
 
INSERT INTO `wp_hfecommwpsc_submited_form_data` VALUES ('1', '1', '15', ''); 
INSERT INTO `wp_hfecommwpsc_submited_form_data` VALUES ('2', '1', '6', '');
# --------------------------------------------------------


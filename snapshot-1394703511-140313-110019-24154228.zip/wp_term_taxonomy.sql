CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_term_taxonomy`;
 
INSERT INTO `wp_term_taxonomy` VALUES ('1', '1', 'category', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('2', '2', 'link_category', '', '0', '7'); 
INSERT INTO `wp_term_taxonomy` VALUES ('3', '3', 'nav_menu', '', '0', '18'); 
INSERT INTO `wp_term_taxonomy` VALUES ('4', '4', 'portfolio_category', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('5', '5', 'portfolio_category', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('6', '6', 'portfolio_category', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('7', '7', 'slideshow_category', '', '0', '6'); 
INSERT INTO `wp_term_taxonomy` VALUES ('8', '8', 'slideshow_category', '', '0', '5'); 
INSERT INTO `wp_term_taxonomy` VALUES ('9', '9', 'product_type', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('10', '10', 'product_type', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('11', '11', 'product_type', '', '0', '40'); 
INSERT INTO `wp_term_taxonomy` VALUES ('12', '12', 'product_type', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('13', '13', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('14', '14', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('15', '15', 'shop_order_status', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('16', '16', 'shop_order_status', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('17', '17', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('18', '18', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('19', '19', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('22', '22', 'pa_farge', '', '0', '4'); 
INSERT INTO `wp_term_taxonomy` VALUES ('23', '23', 'pa_farge', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('24', '24', 'pa_farge', '', '0', '6'); 
INSERT INTO `wp_term_taxonomy` VALUES ('25', '25', 'pa_farge', '', '0', '4'); 
INSERT INTO `wp_term_taxonomy` VALUES ('26', '26', 'pa_farge', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('27', '27', 'pa_farge', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('28', '28', 'pa_farge', '', '0', '4'); 
INSERT INTO `wp_term_taxonomy` VALUES ('29', '29', 'pa_farge', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('30', '30', 'pa_farge', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('31', '31', 'pa_farge', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('32', '32', 'pa_farge', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('33', '33', 'pa_linse', '', '0', '10'); 
INSERT INTO `wp_term_taxonomy` VALUES ('34', '34', 'pa_linse', '', '0', '10'); 
INSERT INTO `wp_term_taxonomy` VALUES ('36', '36', 'language', 'nb_NO', '0', '168'); 
INSERT INTO `wp_term_taxonomy` VALUES ('37', '37', 'language', 'en_US', '0', '57'); 
INSERT INTO `wp_term_taxonomy` VALUES ('38', '38', 'nav_menu', '', '0', '17'); 
INSERT INTO `wp_term_taxonomy` VALUES ('39', '39', 'product_type', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('40', '40', 'pa_farge', '', '0', '20'); 
INSERT INTO `wp_term_taxonomy` VALUES ('41', '41', 'pa_farge', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('42', '42', 'pa_farge', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('43', '43', 'pa_linse', '', '0', '10'); 
INSERT INTO `wp_term_taxonomy` VALUES ('44', '44', 'pa_linse', '', '0', '10'); 
INSERT INTO `wp_term_taxonomy` VALUES ('45', '45', 'pa_farge', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('46', '46', 'pa_farge', '', '0', '4'); 
INSERT INTO `wp_term_taxonomy` VALUES ('47', '47', 'pa_farge', '', '0', '6'); 
INSERT INTO `wp_term_taxonomy` VALUES ('48', '48', 'pa_farge', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('49', '49', 'pa_farge', '', '0', '20'); 
INSERT INTO `wp_term_taxonomy` VALUES ('50', '50', 'pa_farge', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('51', '51', 'pa_farge', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('52', '52', 'pa_farge', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('53', '53', 'pa_farge', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('54', '54', 'pa_farge', '', '0', '4'); 
INSERT INTO `wp_term_taxonomy` VALUES ('55', '55', 'pa_farge', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('56', '56', 'pa_farge', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('57', '57', 'pa_farge', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('58', '58', 'pa_farge', '', '0', '4'); 
INSERT INTO `wp_term_taxonomy` VALUES ('59', '59', 'product_type', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('60', '60', 'product_cat', '', '0', '10'); 
INSERT INTO `wp_term_taxonomy` VALUES ('61', '61', 'product_cat', '', '0', '10'); 
INSERT INTO `wp_term_taxonomy` VALUES ('62', '62', 'slideshow_category', '', '0', '5'); 
INSERT INTO `wp_term_taxonomy` VALUES ('63', '63', 'slideshow_category', '', '0', '6'); 
INSERT INTO `wp_term_taxonomy` VALUES ('64', '64', 'category', '', '0', '3'); 
INSERT INTO `wp_term_taxonomy` VALUES ('65', '65', 'category', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('66', '66', 'product_cat', '', '0', '4'); 
INSERT INTO `wp_term_taxonomy` VALUES ('67', '67', 'product_cat', '', '0', '5'); 
INSERT INTO `wp_term_taxonomy` VALUES ('69', '69', 'product_cat', '', '0', '10'); 
INSERT INTO `wp_term_taxonomy` VALUES ('70', '70', 'product_cat', '', '0', '10');
# --------------------------------------------------------


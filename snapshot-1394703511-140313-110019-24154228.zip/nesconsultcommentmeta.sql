CREATE TABLE IF NOT EXISTS `nesconsultcommentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `nesconsultcommentmeta`;
 
INSERT INTO `nesconsultcommentmeta` VALUES ('1', '2', '_wp_trash_meta_status', '0');
# --------------------------------------------------------


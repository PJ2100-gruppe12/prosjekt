CREATE TABLE IF NOT EXISTS `ska_mtouchquiz_ratings` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `quiz_id` int(11) unsigned NOT NULL,
  `score_rating` varchar(1024) CHARACTER SET utf8 NOT NULL,
  `min_points` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
TRUNCATE TABLE `ska_mtouchquiz_ratings`;

# --------------------------------------------------------


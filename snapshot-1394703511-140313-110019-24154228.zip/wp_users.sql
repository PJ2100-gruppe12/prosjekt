CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_users`;
 
INSERT INTO `wp_users` VALUES ('1', 'admin', '$P$BD/Ao6mcMAYfy7320QW6hIq0JASgmK.', 'admin', 'solveigmarianes@gmail.com', '', '2012-11-06 20:59:41', '', '0', 'admin'); 
INSERT INTO `wp_users` VALUES ('2', 'preview', '$P$BpcZrYLcGypEFHIZhVTl5brB5sEc1s/', 'preview', 'solveig@nesconsult.no', '', '2012-11-19 18:25:47', '', '0', 'preview'); 
INSERT INTO `wp_users` VALUES ('3', 'guru', '$P$BkTmVkIgiWY84D7ylxOS/ZWLOL00.a1', 'guru', 'solveigmaria@me.com', '', '2012-11-22 16:38:07', '', '0', 'guru'); 
INSERT INTO `wp_users` VALUES ('4', 'anders', '$P$Bl.qVjwzIlCyOLzr586aSBxBaMAfaB.', 'anders', 'anders@gunnarscorporate.com', '', '2013-01-26 11:22:27', '', '0', 'Anders Lima Bjølgerud');
# --------------------------------------------------------


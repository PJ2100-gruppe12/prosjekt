CREATE TABLE IF NOT EXISTS `istian_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `istian_usermeta`;
 
INSERT INTO `istian_usermeta` VALUES ('1', '1', 'first_name', ''); 
INSERT INTO `istian_usermeta` VALUES ('2', '1', 'last_name', ''); 
INSERT INTO `istian_usermeta` VALUES ('3', '1', 'nickname', 'admin'); 
INSERT INTO `istian_usermeta` VALUES ('4', '1', 'description', ''); 
INSERT INTO `istian_usermeta` VALUES ('5', '1', 'rich_editing', 'true'); 
INSERT INTO `istian_usermeta` VALUES ('6', '1', 'comment_shortcuts', 'false'); 
INSERT INTO `istian_usermeta` VALUES ('7', '1', 'admin_color', 'fresh'); 
INSERT INTO `istian_usermeta` VALUES ('8', '1', 'use_ssl', '0'); 
INSERT INTO `istian_usermeta` VALUES ('9', '1', 'show_admin_bar_front', 'true'); 
INSERT INTO `istian_usermeta` VALUES ('10', '1', 'istian_capabilities', 'a:1:{s:13:"administrator";s:1:"1";}'); 
INSERT INTO `istian_usermeta` VALUES ('11', '1', 'istian_user_level', '10'); 
INSERT INTO `istian_usermeta` VALUES ('12', '1', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media'); 
INSERT INTO `istian_usermeta` VALUES ('13', '1', 'show_welcome_panel', '1'); 
INSERT INTO `istian_usermeta` VALUES ('14', '1', 'istian_dashboard_quick_press_last_post_id', '31'); 
INSERT INTO `istian_usermeta` VALUES ('15', '1', 'istian_user-settings', 'libraryContent=browse&imgsize=full&hidetb=1&editor=html'); 
INSERT INTO `istian_usermeta` VALUES ('16', '1', 'istian_user-settings-time', '1366980102'); 
INSERT INTO `istian_usermeta` VALUES ('17', '1', '_wpsc_customer_profile', 'a:6:{s:4:"cart";s:1046:"O:9:"wpsc_cart":37:{s:16:"delivery_country";s:2:"NO";s:16:"selected_country";s:2:"NO";s:15:"delivery_region";b:0;s:15:"selected_region";b:0;s:24:"selected_shipping_method";N;s:24:"selected_shipping_option";N;s:24:"selected_shipping_amount";N;s:6:"coupon";N;s:14:"tax_percentage";N;s:9:"unique_id";s:40:"f50183f31646a5bf5e718e7782b865a903f82c05";s:6:"errors";a:0:{}s:9:"total_tax";N;s:13:"base_shipping";N;s:19:"total_item_shipping";N;s:14:"total_shipping";N;s:8:"subtotal";N;s:11:"total_price";N;s:13:"uses_shipping";N;s:13:"is_incomplete";b:1;s:10:"cart_items";a:0:{}s:9:"cart_item";N;s:15:"cart_item_count";i:0;s:17:"current_cart_item";i:-1;s:11:"in_the_loop";b:0;s:16:"shipping_methods";b:0;s:15:"shipping_method";N;s:21:"shipping_method_count";i:1;s:23:"current_shipping_method";i:-1;s:18:"in_the_method_loop";b:0;s:15:"shipping_quotes";a:0:{}s:14:"shipping_quote";N;s:20:"shipping_quote_count";i:0;s:22:"current_shipping_quote";i:-1;s:17:"in_the_quote_loop";b:0;s:12:"coupons_name";s:0:"";s:14:"coupons_amount";i:0;s:15:"shipping_option";N;}";s:16:"shipping_country";s:2:"NO";s:15:"billing_country";s:2:"NO";s:15:"shipping_region";b:0;s:14:"billing_region";b:0;s:40:"category_shipping_target_market_conflict";b:0;}'); 
INSERT INTO `istian_usermeta` VALUES ('18', '1', 'cpoints', '200');
# --------------------------------------------------------


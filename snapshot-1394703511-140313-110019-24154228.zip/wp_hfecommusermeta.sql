CREATE TABLE IF NOT EXISTS `wp_hfecommusermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_hfecommusermeta`;
 
INSERT INTO `wp_hfecommusermeta` VALUES ('1', '1', 'first_name', ''); 
INSERT INTO `wp_hfecommusermeta` VALUES ('2', '1', 'last_name', ''); 
INSERT INTO `wp_hfecommusermeta` VALUES ('3', '1', 'nickname', 'admin'); 
INSERT INTO `wp_hfecommusermeta` VALUES ('4', '1', 'description', ''); 
INSERT INTO `wp_hfecommusermeta` VALUES ('5', '1', 'rich_editing', 'true'); 
INSERT INTO `wp_hfecommusermeta` VALUES ('6', '1', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_hfecommusermeta` VALUES ('7', '1', 'admin_color', 'fresh'); 
INSERT INTO `wp_hfecommusermeta` VALUES ('8', '1', 'use_ssl', '0'); 
INSERT INTO `wp_hfecommusermeta` VALUES ('9', '1', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_hfecommusermeta` VALUES ('10', '1', 'wp_hfecommcapabilities', 'a:1:{s:13:"administrator";s:1:"1";}'); 
INSERT INTO `wp_hfecommusermeta` VALUES ('11', '1', 'wp_hfecommuser_level', '10'); 
INSERT INTO `wp_hfecommusermeta` VALUES ('12', '1', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets'); 
INSERT INTO `wp_hfecommusermeta` VALUES ('13', '1', 'show_welcome_panel', '1'); 
INSERT INTO `wp_hfecommusermeta` VALUES ('14', '1', 'wp_hfecommdashboard_quick_press_last_post_id', '3'); 
INSERT INTO `wp_hfecommusermeta` VALUES ('15', '1', 'wp_hfecommuser-settings', 'hidetb=1&imgsize=full&editor=tinymce'); 
INSERT INTO `wp_hfecommusermeta` VALUES ('16', '1', 'wp_hfecommuser-settings-time', '1351558986'); 
INSERT INTO `wp_hfecommusermeta` VALUES ('17', '1', 'wp_hfecommwpsc_settings_selected_payment_gateway', 'chronopay'); 
INSERT INTO `wp_hfecommusermeta` VALUES ('18', '1', 'wpshpcrt_usr_profile', ''); 
INSERT INTO `wp_hfecommusermeta` VALUES ('19', '1', 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'); 
INSERT INTO `wp_hfecommusermeta` VALUES ('20', '1', 'metaboxhidden_nav-menus', 'a:6:{i:0;s:8:"add-post";i:1;s:11:"add-product";i:2;s:13:"add-portfolio";i:3;s:12:"add-post_tag";i:4;s:15:"add-product_cat";i:5;s:15:"add-product_tag";}');
# --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `ska_mtouchquiz_question` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `quiz_id` int(11) unsigned NOT NULL,
  `question` mediumtext CHARACTER SET utf8 NOT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `point_value` int(3) NOT NULL DEFAULT '100',
  `number_correct` int(3) NOT NULL DEFAULT '1',
  `explanation` mediumtext CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `quiz_id` (`quiz_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
TRUNCATE TABLE `ska_mtouchquiz_question`;

# --------------------------------------------------------


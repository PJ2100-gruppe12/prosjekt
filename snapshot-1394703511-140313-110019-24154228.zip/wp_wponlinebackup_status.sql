CREATE TABLE IF NOT EXISTS `wp_wponlinebackup_status` (
  `status` tinyint(1) unsigned NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `counter` int(10) unsigned NOT NULL,
  `stop_user` varchar(255) NOT NULL,
  `progress` blob NOT NULL,
  PRIMARY KEY (`status`,`time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_wponlinebackup_status`;
 
INSERT INTO `wp_wponlinebackup_status` VALUES ('0', '0', '0', '', '');
# --------------------------------------------------------


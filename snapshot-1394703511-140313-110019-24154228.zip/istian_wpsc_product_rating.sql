CREATE TABLE IF NOT EXISTS `istian_wpsc_product_rating` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ipnum` varchar(30) NOT NULL DEFAULT '',
  `productid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rated` tinyint(1) NOT NULL DEFAULT '0',
  `time` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `istian_wpsc_product_rating`;
 
INSERT INTO `istian_wpsc_product_rating` VALUES ('1', '84.215.154.248', '26', '4', '1366972537');
# --------------------------------------------------------


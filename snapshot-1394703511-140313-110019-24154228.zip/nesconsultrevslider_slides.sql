CREATE TABLE IF NOT EXISTS `nesconsultrevslider_slides` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `slider_id` int(9) NOT NULL,
  `slide_order` int(11) NOT NULL,
  `params` text NOT NULL,
  `layers` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `nesconsultrevslider_slides`;
 
INSERT INTO `nesconsultrevslider_slides` VALUES ('1', '1', '1', '{"background_type":"trans"}', '');
# --------------------------------------------------------


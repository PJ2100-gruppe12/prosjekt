<?php
return array(
	'theme_name' => 'Striking', 
	'theme_slug' => 'striking',
	'theme_version' => '5.1.9.5',
	'required_wp_version' => '3.1',
);
CREATE TABLE IF NOT EXISTS `pj_revslider_slides` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `slider_id` int(9) NOT NULL,
  `slide_order` int(11) NOT NULL,
  `params` text NOT NULL,
  `layers` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `pj_revslider_slides`;
 
INSERT INTO `pj_revslider_slides` VALUES ('1', '2', '1', '{"background_type":"image","image":"http:\\/\\/pj2100.nesconsult.no\\/wp-content\\/uploads\\/2014\\/03\\/Ibex_Wallpaper_by_willwill100.png","image_id":"241","title":"Slide1","state":"published","date_from":"","date_to":"","slide_transition":"random","0":"Choose Image","slot_amount":7,"transition_rotation":0,"transition_duration":300,"delay":"","enable_link":"false","link_type":"regular","link":"","link_open_in":"same","slide_link":"nothing","link_pos":"front","slide_thumb":"","slide_bg_color":"#E7E7E7","slide_bg_external":"","bg_fit":"cover","bg_fit_x":"100","bg_fit_y":"100","bg_repeat":"no-repeat","bg_position":"center top","bg_position_x":"0","bg_position_y":"0","kenburn_effect":"off","kb_start_fit":"100","kb_end_fit":"100","bg_end_position":"center top","kb_duration":"9000","kb_easing":"Linear.easeNone"}', '[{"text":"Dette er en superslider","type":"text","left":142,"top":147,"animation":"lfr","easing":"Power3.easeInOut","speed":300,"align_hor":"left","align_vert":"top","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","style":"large_bold_white","time":500,"endtime":"","endspeed":300,"endanimation":"auto","endeasing":"nothing","corner_left":"nothing","corner_right":"nothing","width":690,"height":60,"serial":0,"endTimeFinal":8700,"endSpeedFinal":300,"realEndTime":9000,"timeLast":8500,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":"","link_id":"","link_class":"","link_title":"","link_rel":""}]');
# --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `pj_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `pj_comments`;
 
INSERT INTO `pj_comments` VALUES ('1', '1', 'Mr WordPress', '', 'http://wordpress.org/', '', '2014-03-10 14:47:05', '2014-03-10 14:47:05', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', '0', 'trash', '', '', '0', '0'); 
INSERT INTO `pj_comments` VALUES ('2', '132', 'test test', 'ksnippen@gmail.com', '', '158.36.84.170', '2014-03-13 14:10:27', '2014-03-13 14:10:27', 'Heisann', '0', 'trash', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36 OPR/20.0.1387.64', '', '0', '7'); 
INSERT INTO `pj_comments` VALUES ('3', '139', 'test_Student', 'ksnippen@gmail.com', '', '158.36.84.170', '2014-03-18 12:51:58', '2014-03-18 11:51:58', 'Heisann', '0', '0', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:27.0) Gecko/20100101 Firefox/27.0', '', '0', '10');
# --------------------------------------------------------


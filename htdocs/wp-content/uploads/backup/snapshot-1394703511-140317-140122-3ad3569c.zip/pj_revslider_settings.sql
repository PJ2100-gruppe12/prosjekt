CREATE TABLE IF NOT EXISTS `pj_revslider_settings` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `general` text NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `pj_revslider_settings`;
 
INSERT INTO `pj_revslider_settings` VALUES ('1', 'a:4:{s:4:"role";s:5:"admin";s:17:"includes_globally";s:2:"on";s:18:"pages_for_includes";s:0:"";s:12:"js_to_footer";s:3:"off";}', '');
# --------------------------------------------------------


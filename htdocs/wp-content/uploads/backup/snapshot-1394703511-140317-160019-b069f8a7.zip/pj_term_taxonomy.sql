CREATE TABLE IF NOT EXISTS `pj_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `pj_term_taxonomy`;
 
INSERT INTO `pj_term_taxonomy` VALUES ('1', '1', 'category', '', '0', '1'); 
INSERT INTO `pj_term_taxonomy` VALUES ('2', '2', 'category', '', '0', '0'); 
INSERT INTO `pj_term_taxonomy` VALUES ('3', '3', 'category', '', '2', '1'); 
INSERT INTO `pj_term_taxonomy` VALUES ('4', '4', 'category', '', '2', '1'); 
INSERT INTO `pj_term_taxonomy` VALUES ('5', '5', 'category', '', '2', '0'); 
INSERT INTO `pj_term_taxonomy` VALUES ('6', '2', 'eab_events_category', '', '0', '2'); 
INSERT INTO `pj_term_taxonomy` VALUES ('7', '3', 'eab_events_category', '', '2', '0'); 
INSERT INTO `pj_term_taxonomy` VALUES ('8', '4', 'eab_events_category', '', '2', '1'); 
INSERT INTO `pj_term_taxonomy` VALUES ('9', '5', 'eab_events_category', '', '2', '1'); 
INSERT INTO `pj_term_taxonomy` VALUES ('10', '6', 'eab_events_category', '', '2', '3'); 
INSERT INTO `pj_term_taxonomy` VALUES ('12', '6', 'category', '', '2', '1'); 
INSERT INTO `pj_term_taxonomy` VALUES ('11', '7', 'nav_menu', '', '0', '16'); 
INSERT INTO `pj_term_taxonomy` VALUES ('13', '2', 'incsub_wiki_category', '', '0', '1'); 
INSERT INTO `pj_term_taxonomy` VALUES ('14', '8', 'incsub_wiki_category', '', '2', '1');
# --------------------------------------------------------


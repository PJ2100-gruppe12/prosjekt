CREATE TABLE IF NOT EXISTS `goldenaterms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `goldenaterms`;
 
INSERT INTO `goldenaterms` VALUES ('1', 'Aktuelt', 'aktuelt', '0'); 
INSERT INTO `goldenaterms` VALUES ('2', 'Blogroll', 'blogroll', '0'); 
INSERT INTO `goldenaterms` VALUES ('3', 'Menystruktur', 'menystruktur', '0'); 
INSERT INTO `goldenaterms` VALUES ('4', 'media', 'media', '0'); 
INSERT INTO `goldenaterms` VALUES ('5', 'Ukategorisert', 'ukategorisert', '0');
# --------------------------------------------------------


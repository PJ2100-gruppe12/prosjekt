CREATE TABLE IF NOT EXISTS `nesconsultcomments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `nesconsultcomments`;
 
INSERT INTO `nesconsultcomments` VALUES ('1', '1', 'Mr WordPress', '', 'http://wordpress.org/', '', '2012-04-03 21:13:24', '2012-04-03 21:13:24', 'Hi, this is a comment.<br />To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', '0', '1', '', '', '0', '0'); 
INSERT INTO `nesconsultcomments` VALUES ('2', '490', 'Patricia', 'vekdhhs@gmail.com', 'http://gmbal.com/511c', '5.34.247.170', '2013-11-06 03:23:36', '2013-11-06 03:23:36', 'Do you need more website traffic? I was told about a service that offers a free trial to try their service and make sure it works for you. They offer keyword targeted traffic so that you only get visitors that are interested in your website. I am getting a lot more ad revenue now that I am using their service. Check it out here: http://gmbal.com/511c', '0', 'spam', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) )', '', '0', '0');
# --------------------------------------------------------


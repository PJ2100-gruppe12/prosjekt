CREATE TABLE IF NOT EXISTS `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) NOT NULL,
  `attribute_label` longtext,
  `attribute_type` varchar(200) NOT NULL,
  PRIMARY KEY (`attribute_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_woocommerce_attribute_taxonomies`;
 
INSERT INTO `wp_woocommerce_attribute_taxonomies` VALUES ('1', 'farge', 'Farge', 'select'); 
INSERT INTO `wp_woocommerce_attribute_taxonomies` VALUES ('2', 'linse', 'Linse', 'select');
# --------------------------------------------------------


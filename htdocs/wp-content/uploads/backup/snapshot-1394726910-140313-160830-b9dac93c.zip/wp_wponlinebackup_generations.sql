CREATE TABLE IF NOT EXISTS `wp_wponlinebackup_generations` (
  `bin` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `backup_time` int(10) unsigned NOT NULL,
  `deleted_time` int(10) unsigned DEFAULT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  `stored_size` int(10) unsigned DEFAULT NULL,
  `mod_time` int(10) unsigned DEFAULT NULL,
  `new_deleted_time` int(10) unsigned DEFAULT NULL,
  `commit` smallint(1) unsigned NOT NULL,
  PRIMARY KEY (`bin`,`item_id`,`backup_time`),
  KEY `commit` (`commit`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_wponlinebackup_generations`;

# --------------------------------------------------------


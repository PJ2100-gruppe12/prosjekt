CREATE TABLE IF NOT EXISTS `wp_woocommerce_termmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `woocommerce_term_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_woocommerce_termmeta`;
 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('3', '22', 'order_pa_farge', '28'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('4', '23', 'order_pa_farge', '27'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('5', '24', 'order_pa_farge', '26'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('6', '25', 'order_pa_farge', '25'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('7', '26', 'order_pa_farge', '24'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('8', '27', 'order_pa_farge', '23'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('9', '28', 'order_pa_farge', '22'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('10', '29', 'order_pa_farge', '21'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('11', '30', 'order_pa_farge', '20'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('12', '31', 'order_pa_farge', '19'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('13', '32', 'order_pa_farge', '18'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('14', '33', 'order_pa_linse', '4'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('15', '34', 'order_pa_linse', '3'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('17', '36', 'order', '2'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('18', '37', 'order', '1'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('19', '38', 'order', '1'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('20', '3', 'order', '2'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('21', '39', 'order', '6'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('22', '12', 'order', '2'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('23', '10', 'order', '3'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('24', '9', 'order', '4'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('25', '11', 'order', '5'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('26', '40', 'order_pa_farge', '17'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('27', '41', 'order_pa_farge', '16'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('28', '42', 'order_pa_farge', '15'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('29', '43', 'order_pa_linse', '2'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('30', '44', 'order_pa_linse', '1'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('31', '45', 'order_pa_farge', '14'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('32', '46', 'order_pa_farge', '13'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('33', '47', 'order_pa_farge', '12'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('34', '48', 'order_pa_farge', '11'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('35', '49', 'order_pa_farge', '10'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('36', '50', 'order_pa_farge', '9'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('37', '51', 'order_pa_farge', '8'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('38', '52', 'order_pa_farge', '7'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('39', '53', 'order_pa_farge', '6'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('40', '54', 'order_pa_farge', '5'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('41', '55', 'order_pa_farge', '4'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('42', '56', 'order_pa_farge', '3'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('43', '57', 'order_pa_farge', '2'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('44', '58', 'order_pa_farge', '1'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('45', '59', 'order', '1'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('46', '60', 'order', '6'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('47', '60', 'thumbnail_id', ''); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('48', '61', 'order', '5'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('49', '61', 'thumbnail_id', ''); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('50', '62', 'order', '3'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('51', '8', 'order', '2'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('52', '7', 'order', '4'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('53', '63', 'order', '1'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('54', '64', 'order', '2'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('55', '1', 'order', '3'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('56', '65', 'order', '1'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('57', '66', 'order', '4'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('58', '66', 'thumbnail_id', ''); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('59', '67', 'order', '3'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('60', '67', 'thumbnail_id', ''); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('63', '69', 'order', '2'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('64', '69', 'thumbnail_id', ''); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('65', '70', 'order', '1'); 
INSERT INTO `wp_woocommerce_termmeta` VALUES ('66', '70', 'thumbnail_id', '');
# --------------------------------------------------------


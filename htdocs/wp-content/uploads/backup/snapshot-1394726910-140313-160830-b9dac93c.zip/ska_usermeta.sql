CREATE TABLE IF NOT EXISTS `ska_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `ska_usermeta`;
 
INSERT INTO `ska_usermeta` VALUES ('1', '1', 'first_name', ''); 
INSERT INTO `ska_usermeta` VALUES ('2', '1', 'last_name', ''); 
INSERT INTO `ska_usermeta` VALUES ('3', '1', 'nickname', 'admin'); 
INSERT INTO `ska_usermeta` VALUES ('4', '1', 'description', ''); 
INSERT INTO `ska_usermeta` VALUES ('5', '1', 'rich_editing', 'true'); 
INSERT INTO `ska_usermeta` VALUES ('6', '1', 'comment_shortcuts', 'false'); 
INSERT INTO `ska_usermeta` VALUES ('7', '1', 'admin_color', 'fresh'); 
INSERT INTO `ska_usermeta` VALUES ('8', '1', 'use_ssl', '0'); 
INSERT INTO `ska_usermeta` VALUES ('9', '1', 'show_admin_bar_front', 'true'); 
INSERT INTO `ska_usermeta` VALUES ('10', '1', 'ska_capabilities', 'a:1:{s:13:"administrator";s:1:"1";}'); 
INSERT INTO `ska_usermeta` VALUES ('11', '1', 'ska_user_level', '10'); 
INSERT INTO `ska_usermeta` VALUES ('12', '1', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media'); 
INSERT INTO `ska_usermeta` VALUES ('13', '1', 'show_welcome_panel', '1'); 
INSERT INTO `ska_usermeta` VALUES ('14', '1', 'ska_dashboard_quick_press_last_post_id', '3'); 
INSERT INTO `ska_usermeta` VALUES ('15', '2', 'first_name', 'Solveig Kristine'); 
INSERT INTO `ska_usermeta` VALUES ('16', '2', 'last_name', 'Apelthun'); 
INSERT INTO `ska_usermeta` VALUES ('17', '2', 'nickname', 'solveig'); 
INSERT INTO `ska_usermeta` VALUES ('18', '2', 'description', ''); 
INSERT INTO `ska_usermeta` VALUES ('19', '2', 'rich_editing', 'true'); 
INSERT INTO `ska_usermeta` VALUES ('20', '2', 'comment_shortcuts', 'false'); 
INSERT INTO `ska_usermeta` VALUES ('21', '2', 'admin_color', 'fresh'); 
INSERT INTO `ska_usermeta` VALUES ('22', '2', 'use_ssl', '0'); 
INSERT INTO `ska_usermeta` VALUES ('23', '2', 'show_admin_bar_front', 'true'); 
INSERT INTO `ska_usermeta` VALUES ('24', '2', 'ska_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `ska_usermeta` VALUES ('25', '2', 'ska_user_level', '10'); 
INSERT INTO `ska_usermeta` VALUES ('26', '2', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media'); 
INSERT INTO `ska_usermeta` VALUES ('27', '1', 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'); 
INSERT INTO `ska_usermeta` VALUES ('28', '1', 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'); 
INSERT INTO `ska_usermeta` VALUES ('29', '1', 'ska_user-settings', 'hidetb=1'); 
INSERT INTO `ska_usermeta` VALUES ('30', '1', 'ska_user-settings-time', '1365419675'); 
INSERT INTO `ska_usermeta` VALUES ('31', '2', 'ska_dashboard_quick_press_last_post_id', '13');
# --------------------------------------------------------


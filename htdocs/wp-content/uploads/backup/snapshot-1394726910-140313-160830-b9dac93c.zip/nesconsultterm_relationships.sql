CREATE TABLE IF NOT EXISTS `nesconsultterm_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `nesconsultterm_relationships`;
 
INSERT INTO `nesconsultterm_relationships` VALUES ('1', '2', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('2', '2', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('3', '2', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('4', '2', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('5', '2', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('6', '2', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('7', '2', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('1', '1', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('34', '3', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('63', '4', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('74', '3', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('73', '3', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('75', '4', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('80', '4', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('75', '5', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('63', '5', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('91', '4', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('99', '6', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('99', '4', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('101', '4', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('105', '14', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('110', '14', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('112', '14', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('122', '11', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('125', '11', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('101', '15', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('99', '18', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('99', '17', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('99', '16', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('99', '15', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('91', '15', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('80', '15', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('63', '17', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('63', '15', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('352', '18', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('352', '17', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('352', '16', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('352', '15', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('75', '17', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('75', '15', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('426', '3', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('430', '3', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('429', '3', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('428', '3', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('427', '3', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('434', '3', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('437', '3', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('8', '19', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('9', '19', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('10', '19', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('11', '19', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('12', '19', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('466', '5', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('473', '14', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('475', '14', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('482', '5', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('484', '5', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('489', '5', '0'); 
INSERT INTO `nesconsultterm_relationships` VALUES ('490', '4', '0');
# --------------------------------------------------------


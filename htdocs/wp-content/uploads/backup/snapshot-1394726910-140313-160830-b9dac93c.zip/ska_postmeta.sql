CREATE TABLE IF NOT EXISTS `ska_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `ska_postmeta`;
 
INSERT INTO `ska_postmeta` VALUES ('2', '4', '_wp_attached_file', '2013/04/cropped-forberedt.no_.png'); 
INSERT INTO `ska_postmeta` VALUES ('3', '4', '_wp_attachment_context', 'custom-header'); 
INSERT INTO `ska_postmeta` VALUES ('4', '4', '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:288;s:4:"file";s:33:"2013/04/cropped-forberedt.no_.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"cropped-forberedt.no_-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:32:"cropped-forberedt.no_-300x86.png";s:5:"width";i:300;s:6:"height";i:86;s:9:"mime-type";s:9:"image/png";}s:13:"small-feature";a:4:{s:4:"file";s:33:"cropped-forberedt.no_-500x144.png";s:5:"width";i:500;s:6:"height";i:144;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `ska_postmeta` VALUES ('5', '4', '_wp_attachment_is_custom_header', 'twentyeleven'); 
INSERT INTO `ska_postmeta` VALUES ('6', '5', '_edit_last', '1'); 
INSERT INTO `ska_postmeta` VALUES ('7', '5', '_edit_lock', '1365419681:1'); 
INSERT INTO `ska_postmeta` VALUES ('8', '5', '_wp_page_template', 'sidebar-page.php'); 
INSERT INTO `ska_postmeta` VALUES ('9', '7', '_edit_last', '1'); 
INSERT INTO `ska_postmeta` VALUES ('10', '7', '_wp_page_template', 'sidebar-page.php'); 
INSERT INTO `ska_postmeta` VALUES ('11', '7', '_edit_lock', '1365419692:1'); 
INSERT INTO `ska_postmeta` VALUES ('12', '8', '_edit_last', '1'); 
INSERT INTO `ska_postmeta` VALUES ('13', '8', '_wp_page_template', 'sidebar-page.php'); 
INSERT INTO `ska_postmeta` VALUES ('14', '8', '_edit_lock', '1365419673:1');
# --------------------------------------------------------


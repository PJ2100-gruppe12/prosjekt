CREATE TABLE IF NOT EXISTS `pj_calendar_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(30) COLLATE utf8_danish_ci NOT NULL,
  `category_colour` varchar(30) COLLATE utf8_danish_ci NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci;
TRUNCATE TABLE `pj_calendar_categories`;
 
INSERT INTO `pj_calendar_categories` VALUES ('1', 'General', '#F6F79B');
# --------------------------------------------------------


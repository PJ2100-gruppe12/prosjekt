CREATE TABLE IF NOT EXISTS `pj_pieregister_code` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `created` date NOT NULL,
  `modified` date NOT NULL,
  `name` text NOT NULL,
  `count` int(5) NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
TRUNCATE TABLE `pj_pieregister_code`;

# --------------------------------------------------------


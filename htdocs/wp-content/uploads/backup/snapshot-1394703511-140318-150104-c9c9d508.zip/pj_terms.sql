CREATE TABLE IF NOT EXISTS `pj_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `pj_terms`;
 
INSERT INTO `pj_terms` VALUES ('1', 'Uncategorized', 'uncategorized', '0'); 
INSERT INTO `pj_terms` VALUES ('2', 'Utvalg', 'utvalg', '0'); 
INSERT INTO `pj_terms` VALUES ('3', 'Idrettsutvalget', 'idrettsutvalget', '0'); 
INSERT INTO `pj_terms` VALUES ('4', 'Prosjektutvalget for spill', 'prosjektutvalget-for-spill', '0'); 
INSERT INTO `pj_terms` VALUES ('5', '#fuBar', 'fubar', '0'); 
INSERT INTO `pj_terms` VALUES ('6', 'Kvinner og IT', 'kvinner-og-it', '0'); 
INSERT INTO `pj_terms` VALUES ('7', 'Meny', 'meny', '0'); 
INSERT INTO `pj_terms` VALUES ('8', 'Utvalgsdrift', 'utvalgsdrift', '0'); 
INSERT INTO `pj_terms` VALUES ('9', 'markedsføring', 'markedsforing', '0'); 
INSERT INTO `pj_terms` VALUES ('10', 'mat', 'mat', '0'); 
INSERT INTO `pj_terms` VALUES ('11', 'transport', 'transport', '0'); 
INSERT INTO `pj_terms` VALUES ('12', 'foredrag', 'foredrag', '0'); 
INSERT INTO `pj_terms` VALUES ('13', 'rombooking', 'rombooking', '0'); 
INSERT INTO `pj_terms` VALUES ('14', 'refusjoner', 'refusjoner', '0'); 
INSERT INTO `pj_terms` VALUES ('15', 'økonomi', 'okonomi', '0');
# --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `pj_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `pj_term_relationships`;
 
INSERT INTO `pj_term_relationships` VALUES ('1', '1', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('5', '1', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('125', '9', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('28', '3', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('47', '4', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('125', '6', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('132', '8', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('130', '4', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('132', '6', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('150', '11', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('143', '2', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('143', '4', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('287', '11', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('155', '11', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('154', '11', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('156', '11', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('153', '11', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('152', '11', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('149', '11', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('148', '11', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('151', '11', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('139', '10', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('161', '10', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('174', '10', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('271', '11', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('176', '12', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('276', '11', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('279', '11', '0'); 
INSERT INTO `pj_term_relationships` VALUES ('284', '11', '0');
# --------------------------------------------------------


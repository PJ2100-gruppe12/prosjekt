CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_terms`;
 
INSERT INTO `wp_terms` VALUES ('1', 'Uncategorized', 'uncategorized', '0'); 
INSERT INTO `wp_terms` VALUES ('2', 'Blogroll', 'blogroll', '0'); 
INSERT INTO `wp_terms` VALUES ('3', 'norsk', 'norsk', '0'); 
INSERT INTO `wp_terms` VALUES ('4', 'MED STYRKE', 'med-styrke', '0'); 
INSERT INTO `wp_terms` VALUES ('5', 'CRYSTALLINE LINSER', 'crystalline-linser', '0'); 
INSERT INTO `wp_terms` VALUES ('6', 'TILBEHØR', 'tilbehor', '0'); 
INSERT INTO `wp_terms` VALUES ('7', 'whataregunnars', 'whataregunnars', '0'); 
INSERT INTO `wp_terms` VALUES ('8', 'front', 'front', '0'); 
INSERT INTO `wp_terms` VALUES ('9', 'simple', 'simple', '0'); 
INSERT INTO `wp_terms` VALUES ('10', 'grouped', 'grouped', '0'); 
INSERT INTO `wp_terms` VALUES ('11', 'variable', 'variable', '0'); 
INSERT INTO `wp_terms` VALUES ('12', 'external', 'external', '0'); 
INSERT INTO `wp_terms` VALUES ('13', 'pending', 'pending', '0'); 
INSERT INTO `wp_terms` VALUES ('14', 'failed', 'failed', '0'); 
INSERT INTO `wp_terms` VALUES ('15', 'on-hold', 'on-hold', '0'); 
INSERT INTO `wp_terms` VALUES ('16', 'processing', 'processing', '0'); 
INSERT INTO `wp_terms` VALUES ('17', 'completed', 'completed', '0'); 
INSERT INTO `wp_terms` VALUES ('18', 'refunded', 'refunded', '0'); 
INSERT INTO `wp_terms` VALUES ('19', 'cancelled', 'cancelled', '0'); 
INSERT INTO `wp_terms` VALUES ('22', 'Espresso', 'espresso', '0'); 
INSERT INTO `wp_terms` VALUES ('23', 'Ash', 'ash', '0'); 
INSERT INTO `wp_terms` VALUES ('24', 'Mercury', 'mercury', '0'); 
INSERT INTO `wp_terms` VALUES ('25', 'Graphite', 'graphite', '0'); 
INSERT INTO `wp_terms` VALUES ('26', 'Gunmetal', 'gunmetal', '0'); 
INSERT INTO `wp_terms` VALUES ('27', 'Crimson', 'crimson', '0'); 
INSERT INTO `wp_terms` VALUES ('28', 'Tortoise', 'tortoise', '0'); 
INSERT INTO `wp_terms` VALUES ('29', 'Onyx fade', 'onyxfade', '0'); 
INSERT INTO `wp_terms` VALUES ('30', 'Amethyst', 'amethyst', '0'); 
INSERT INTO `wp_terms` VALUES ('31', 'Earth', 'earth', '0'); 
INSERT INTO `wp_terms` VALUES ('32', 'Onyx / Gunmetal', 'onyxgunmetal', '0'); 
INSERT INTO `wp_terms` VALUES ('33', 'Amber', 'amber', '0'); 
INSERT INTO `wp_terms` VALUES ('34', 'Crystalline', 'crystalline', '0'); 
INSERT INTO `wp_terms` VALUES ('36', 'Norsk', 'nb', '1'); 
INSERT INTO `wp_terms` VALUES ('37', 'English', 'en', '2'); 
INSERT INTO `wp_terms` VALUES ('38', 'english', 'english', '0'); 
INSERT INTO `wp_terms` VALUES ('39', 'variable', 'variable-en', '0'); 
INSERT INTO `wp_terms` VALUES ('40', 'Onyx', 'onyx', '0'); 
INSERT INTO `wp_terms` VALUES ('41', 'Pale rose', 'pale-rose', '0'); 
INSERT INTO `wp_terms` VALUES ('42', 'Steel blue', 'steel-blue', '0'); 
INSERT INTO `wp_terms` VALUES ('43', 'Amber', 'amber-en', '0'); 
INSERT INTO `wp_terms` VALUES ('44', 'Crystalline', 'crystalline-en', '0'); 
INSERT INTO `wp_terms` VALUES ('45', 'Steel blue', 'steel-blue-en', '0'); 
INSERT INTO `wp_terms` VALUES ('46', 'Graphite', 'graphite-en', '0'); 
INSERT INTO `wp_terms` VALUES ('47', 'Mercury', 'mercury-en', '0'); 
INSERT INTO `wp_terms` VALUES ('48', 'Pale rose', 'pale-rose-en', '0'); 
INSERT INTO `wp_terms` VALUES ('49', 'Onyx', 'onyx-en', '0'); 
INSERT INTO `wp_terms` VALUES ('50', 'Onyx / Gunmetal', 'onyxgunmetal-en', '0'); 
INSERT INTO `wp_terms` VALUES ('51', 'Earth', 'earth-en', '0'); 
INSERT INTO `wp_terms` VALUES ('52', 'Amethyst', 'amethyst-en', '0'); 
INSERT INTO `wp_terms` VALUES ('53', 'Onyx fade', 'onyxfade-en', '0'); 
INSERT INTO `wp_terms` VALUES ('54', 'Tortoise', 'tortoise-en', '0'); 
INSERT INTO `wp_terms` VALUES ('55', 'Crimson', 'crimson-en', '0'); 
INSERT INTO `wp_terms` VALUES ('56', 'Gunmetal', 'gunmetal-en', '0'); 
INSERT INTO `wp_terms` VALUES ('57', 'Ash', 'ash-en', '0'); 
INSERT INTO `wp_terms` VALUES ('58', 'Espresso', 'espresso-en', '0'); 
INSERT INTO `wp_terms` VALUES ('59', 'variable', 'variable-nb', '0'); 
INSERT INTO `wp_terms` VALUES ('60', 'Advanced Computer Eyewear', 'ace', '0'); 
INSERT INTO `wp_terms` VALUES ('61', 'Advanced Computer Eyewear EN', 'ace-en', '0'); 
INSERT INTO `wp_terms` VALUES ('62', 'frontEN', 'front-en', '0'); 
INSERT INTO `wp_terms` VALUES ('63', 'whataregunnarsEN', 'whataregunnars-en', '0'); 
INSERT INTO `wp_terms` VALUES ('64', 'Nyheter', 'nyheter', '0'); 
INSERT INTO `wp_terms` VALUES ('65', 'News', 'news', '0'); 
INSERT INTO `wp_terms` VALUES ('66', 'Crystalline for designere', 'catcrystalline', '0'); 
INSERT INTO `wp_terms` VALUES ('67', 'Crystalline for designers', 'catcrystalline-en', '0'); 
INSERT INTO `wp_terms` VALUES ('69', 'GUNNARS med styrke', 'styrke', '0'); 
INSERT INTO `wp_terms` VALUES ('70', 'RX compatible', 'rx-compatible', '0');
# --------------------------------------------------------


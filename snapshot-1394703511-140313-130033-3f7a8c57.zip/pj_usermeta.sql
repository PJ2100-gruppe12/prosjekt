CREATE TABLE IF NOT EXISTS `pj_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `pj_usermeta`;
 
INSERT INTO `pj_usermeta` VALUES ('1', '1', 'first_name', ''); 
INSERT INTO `pj_usermeta` VALUES ('2', '1', 'last_name', ''); 
INSERT INTO `pj_usermeta` VALUES ('3', '1', 'nickname', 'nessol13'); 
INSERT INTO `pj_usermeta` VALUES ('4', '1', 'description', ''); 
INSERT INTO `pj_usermeta` VALUES ('5', '1', 'rich_editing', 'true'); 
INSERT INTO `pj_usermeta` VALUES ('6', '1', 'comment_shortcuts', 'false'); 
INSERT INTO `pj_usermeta` VALUES ('7', '1', 'admin_color', 'fresh'); 
INSERT INTO `pj_usermeta` VALUES ('8', '1', 'use_ssl', '0'); 
INSERT INTO `pj_usermeta` VALUES ('9', '1', 'show_admin_bar_front', 'true'); 
INSERT INTO `pj_usermeta` VALUES ('10', '1', 'pj_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `pj_usermeta` VALUES ('11', '1', 'pj_user_level', '10'); 
INSERT INTO `pj_usermeta` VALUES ('12', '1', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks'); 
INSERT INTO `pj_usermeta` VALUES ('13', '1', 'show_welcome_panel', '1'); 
INSERT INTO `pj_usermeta` VALUES ('14', '1', 'pj_dashboard_quick_press_last_post_id', '3'); 
INSERT INTO `pj_usermeta` VALUES ('15', '2', 'first_name', ''); 
INSERT INTO `pj_usermeta` VALUES ('16', '2', 'last_name', ''); 
INSERT INTO `pj_usermeta` VALUES ('17', '2', 'nickname', 'ervleo13'); 
INSERT INTO `pj_usermeta` VALUES ('18', '2', 'description', ''); 
INSERT INTO `pj_usermeta` VALUES ('19', '2', 'rich_editing', 'true'); 
INSERT INTO `pj_usermeta` VALUES ('20', '2', 'comment_shortcuts', 'false'); 
INSERT INTO `pj_usermeta` VALUES ('21', '2', 'admin_color', 'fresh'); 
INSERT INTO `pj_usermeta` VALUES ('22', '2', 'use_ssl', '0'); 
INSERT INTO `pj_usermeta` VALUES ('23', '2', 'show_admin_bar_front', 'true'); 
INSERT INTO `pj_usermeta` VALUES ('24', '2', 'pj_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `pj_usermeta` VALUES ('25', '2', 'pj_user_level', '10'); 
INSERT INTO `pj_usermeta` VALUES ('26', '2', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks'); 
INSERT INTO `pj_usermeta` VALUES ('27', '3', 'first_name', ''); 
INSERT INTO `pj_usermeta` VALUES ('28', '3', 'last_name', ''); 
INSERT INTO `pj_usermeta` VALUES ('29', '3', 'nickname', 'snikim13'); 
INSERT INTO `pj_usermeta` VALUES ('30', '3', 'description', ''); 
INSERT INTO `pj_usermeta` VALUES ('31', '3', 'rich_editing', 'true'); 
INSERT INTO `pj_usermeta` VALUES ('32', '3', 'comment_shortcuts', 'false'); 
INSERT INTO `pj_usermeta` VALUES ('33', '3', 'admin_color', 'fresh'); 
INSERT INTO `pj_usermeta` VALUES ('34', '3', 'use_ssl', '0'); 
INSERT INTO `pj_usermeta` VALUES ('35', '3', 'show_admin_bar_front', 'true'); 
INSERT INTO `pj_usermeta` VALUES ('36', '3', 'pj_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `pj_usermeta` VALUES ('37', '3', 'pj_user_level', '10'); 
INSERT INTO `pj_usermeta` VALUES ('38', '3', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks'); 
INSERT INTO `pj_usermeta` VALUES ('39', '3', 'pj_dashboard_quick_press_last_post_id', '4'); 
INSERT INTO `pj_usermeta` VALUES ('40', '4', 'first_name', 'Lise'); 
INSERT INTO `pj_usermeta` VALUES ('41', '4', 'last_name', ''); 
INSERT INTO `pj_usermeta` VALUES ('42', '4', 'nickname', 'carlis13'); 
INSERT INTO `pj_usermeta` VALUES ('43', '4', 'description', ''); 
INSERT INTO `pj_usermeta` VALUES ('44', '4', 'rich_editing', 'true'); 
INSERT INTO `pj_usermeta` VALUES ('45', '4', 'comment_shortcuts', 'false'); 
INSERT INTO `pj_usermeta` VALUES ('46', '4', 'admin_color', 'fresh'); 
INSERT INTO `pj_usermeta` VALUES ('47', '4', 'use_ssl', '0'); 
INSERT INTO `pj_usermeta` VALUES ('48', '4', 'show_admin_bar_front', 'true'); 
INSERT INTO `pj_usermeta` VALUES ('49', '4', 'pj_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `pj_usermeta` VALUES ('50', '4', 'pj_user_level', '10'); 
INSERT INTO `pj_usermeta` VALUES ('51', '4', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks'); 
INSERT INTO `pj_usermeta` VALUES ('52', '5', 'first_name', ''); 
INSERT INTO `pj_usermeta` VALUES ('53', '5', 'last_name', ''); 
INSERT INTO `pj_usermeta` VALUES ('54', '5', 'nickname', 'klemag13'); 
INSERT INTO `pj_usermeta` VALUES ('55', '5', 'description', ''); 
INSERT INTO `pj_usermeta` VALUES ('56', '5', 'rich_editing', 'true'); 
INSERT INTO `pj_usermeta` VALUES ('57', '5', 'comment_shortcuts', 'false'); 
INSERT INTO `pj_usermeta` VALUES ('58', '5', 'admin_color', 'fresh'); 
INSERT INTO `pj_usermeta` VALUES ('59', '5', 'use_ssl', '0'); 
INSERT INTO `pj_usermeta` VALUES ('60', '5', 'show_admin_bar_front', 'true'); 
INSERT INTO `pj_usermeta` VALUES ('61', '5', 'pj_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `pj_usermeta` VALUES ('62', '5', 'pj_user_level', '10'); 
INSERT INTO `pj_usermeta` VALUES ('63', '5', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks'); 
INSERT INTO `pj_usermeta` VALUES ('64', '6', 'first_name', ''); 
INSERT INTO `pj_usermeta` VALUES ('65', '6', 'last_name', ''); 
INSERT INTO `pj_usermeta` VALUES ('66', '6', 'nickname', 'haneve13'); 
INSERT INTO `pj_usermeta` VALUES ('67', '6', 'description', ''); 
INSERT INTO `pj_usermeta` VALUES ('68', '6', 'rich_editing', 'true'); 
INSERT INTO `pj_usermeta` VALUES ('69', '6', 'comment_shortcuts', 'false'); 
INSERT INTO `pj_usermeta` VALUES ('70', '6', 'admin_color', 'fresh'); 
INSERT INTO `pj_usermeta` VALUES ('71', '6', 'use_ssl', '0'); 
INSERT INTO `pj_usermeta` VALUES ('72', '6', 'show_admin_bar_front', 'true'); 
INSERT INTO `pj_usermeta` VALUES ('73', '6', 'pj_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `pj_usermeta` VALUES ('74', '6', 'pj_user_level', '10'); 
INSERT INTO `pj_usermeta` VALUES ('75', '6', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks'); 
INSERT INTO `pj_usermeta` VALUES ('76', '6', 'pj_dashboard_quick_press_last_post_id', '8'); 
INSERT INTO `pj_usermeta` VALUES ('77', '4', 'pj_dashboard_quick_press_last_post_id', '6'); 
INSERT INTO `pj_usermeta` VALUES ('78', '5', 'pj_dashboard_quick_press_last_post_id', '9'); 
INSERT INTO `pj_usermeta` VALUES ('79', '2', 'pj_dashboard_quick_press_last_post_id', '10'); 
INSERT INTO `pj_usermeta` VALUES ('80', '3', 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'); 
INSERT INTO `pj_usermeta` VALUES ('81', '3', 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'); 
INSERT INTO `pj_usermeta` VALUES ('82', '4', 'show_welcome_panel', '1'); 
INSERT INTO `pj_usermeta` VALUES ('83', '1', '_wdp_un_has_gravatar', '1'); 
INSERT INTO `pj_usermeta` VALUES ('84', '1', 'pj_user-settings', 'libraryContent=browse&hidetb=1&urlbutton=none&align=left&editor=tinymce'); 
INSERT INTO `pj_usermeta` VALUES ('85', '1', 'pj_user-settings-time', '1394705805'); 
INSERT INTO `pj_usermeta` VALUES ('86', '2', 'pj_user-settings', 'editor=html&hidetb=1&libraryContent=browse'); 
INSERT INTO `pj_usermeta` VALUES ('87', '2', 'pj_user-settings-time', '1394713909'); 
INSERT INTO `pj_usermeta` VALUES ('88', '4', 'default_password_nag', ''); 
INSERT INTO `pj_usermeta` VALUES ('89', '3', 'pj_user-settings', 'libraryContent=browse&imgsize=thumbnail&editor=html'); 
INSERT INTO `pj_usermeta` VALUES ('90', '3', 'pj_user-settings-time', '1394714506'); 
INSERT INTO `pj_usermeta` VALUES ('98', '2', 'meta-box-order_page', 'a:3:{s:4:"side";s:23:"submitdiv,pageparentdiv";s:6:"normal";s:96:"postimagediv,page_general,revisionsdiv,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'); 
INSERT INTO `pj_usermeta` VALUES ('91', '4', 'pj_user-settings', 'hidetb=1&editor=tinymce'); 
INSERT INTO `pj_usermeta` VALUES ('92', '4', 'pj_user-settings-time', '1394712349'); 
INSERT INTO `pj_usermeta` VALUES ('93', '2', 'closedpostboxes_incsub_event', 'a:2:{i:0;s:21:"incsub-event-bookings";i:1;s:19:"incsub-event-wizard";}'); 
INSERT INTO `pj_usermeta` VALUES ('94', '2', 'metaboxhidden_incsub_event', 'a:1:{i:0;s:7:"slugdiv";}'); 
INSERT INTO `pj_usermeta` VALUES ('95', '1', 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'); 
INSERT INTO `pj_usermeta` VALUES ('96', '1', 'metaboxhidden_nav-menus', 'a:5:{i:0;s:8:"add-post";i:1;s:16:"add-incsub_event";i:2;s:13:"add-portfolio";i:3;s:12:"add-post_tag";i:4;s:23:"add-eab_events_category";}'); 
INSERT INTO `pj_usermeta` VALUES ('97', '1', 'nav_menu_recently_edited', '7'); 
INSERT INTO `pj_usermeta` VALUES ('99', '2', 'screen_layout_page', '2');
# --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `nesconsultterm_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `nesconsultterm_taxonomy`;
 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('1', '1', 'category', '', '0', '1'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('2', '2', 'link_category', '', '0', '7'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('3', '3', 'nav_menu', '', '0', '10'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('4', '4', 'portfolio_category', '', '0', '7'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('5', '5', 'portfolio_category', '', '0', '6'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('6', '6', 'portfolio_category', '', '0', '1'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('7', '7', 'slideshow_category', '', '0', '0'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('8', '8', 'slideshow_category', '', '7', '0'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('9', '9', 'slideshow_category', '', '7', '0'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('10', '10', 'slideshow_category', '', '7', '0'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('11', '11', 'slideshow_category', '', '7', '2'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('12', '12', 'slideshow_category', '', '7', '0'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('13', '13', 'slideshow_category', '', '7', '0'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('14', '14', 'slideshow_category', '', '0', '5'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('15', '15', 'category-project', '', '0', '6'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('16', '16', 'category-project', '', '0', '1'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('17', '17', 'category-project', '', '0', '3'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('18', '18', 'category-project', '', '0', '1'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('19', '19', 'link_category', '', '0', '5'); 
INSERT INTO `nesconsultterm_taxonomy` VALUES ('20', '20', 'nav_menu', '', '0', '0');
# --------------------------------------------------------


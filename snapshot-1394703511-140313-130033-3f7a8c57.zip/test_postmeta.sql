CREATE TABLE IF NOT EXISTS `test_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `test_postmeta`;
 
INSERT INTO `test_postmeta` VALUES ('1', '2', '_wp_page_template', 'default');
# --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `wp_wponlinebackup_event_log` (
  `event_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `activity_id` int(10) unsigned NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `event` text NOT NULL,
  PRIMARY KEY (`event_id`),
  KEY `activity_id` (`activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_wponlinebackup_event_log`;

# --------------------------------------------------------

